export interface Student {
  id: number;
  rollNo: string;
  name: string;
  email: string;
  password?: string;
  branch: string;
  year: string;
  avatar?: string;
  createdAt: string;
}

export interface Admin {
  id: number;
  username: string;
  name: string;
  email: string;
  role: string;
}

export interface Option {
  id: string; // 'A' | 'B' | 'C' | 'D'
  text: string;
}

export interface Question {
  id: number;
  quizId: number;
  questionText: string;
  codeSnippet?: string;
  options: {
    A: string;
    B: string;
    C: string;
    D: string;
  };
  correctOption: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  marks: number;
}

export interface Quiz {
  id: number;
  title: string;
  category: string;
  description: string;
  durationMinutes: number;
  totalMarks: number;
  passingPercentage: number;
  iconName: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
}

export interface StudentAnswer {
  questionId: number;
  selectedOption: 'A' | 'B' | 'C' | 'D' | null;
  isMarkedForReview: boolean;
  timeSpentSeconds?: number;
}

export interface QuizResult {
  id: number;
  quizId: number;
  quizTitle: string;
  studentId: number;
  studentName: string;
  studentRollNo: string;
  totalQuestions: number;
  attemptedQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  unansweredQuestions: number;
  scoreObtained: number;
  totalMarks: number;
  percentage: number;
  isPassed: boolean;
  timeTakenSeconds: number;
  submittedAt: string;
  answers: Record<number, 'A' | 'B' | 'C' | 'D' | null>;
}

export type ViewState = 
  | 'home' 
  | 'student-dashboard' 
  | 'quiz-exam' 
  | 'quiz-result' 
  | 'admin-dashboard';
