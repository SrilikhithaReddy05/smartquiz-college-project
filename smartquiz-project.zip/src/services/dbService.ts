import { Student, Admin, Quiz, Question, QuizResult } from '../types/quiz';
import { INITIAL_STUDENTS, INITIAL_QUIZZES, INITIAL_QUESTIONS, INITIAL_RESULTS } from '../data/initialData';

const STORAGE_KEYS = {
  STUDENTS: 'smartquiz_students_v1',
  ADMINS: 'smartquiz_admins_v1',
  QUIZZES: 'smartquiz_quizzes_v1',
  QUESTIONS: 'smartquiz_questions_v1',
  RESULTS: 'smartquiz_results_v1',
  CURRENT_USER: 'smartquiz_current_user_v1',
  CURRENT_ADMIN: 'smartquiz_current_admin_v1',
};

const DEFAULT_ADMIN: Admin = {
  id: 1,
  username: 'admin',
  name: 'Prof. S. R. Sharma (HOD & Exam Controller)',
  email: 'admin@smartquiz.edu',
  role: 'Exam Controller'
};

class DatabaseService {
  private getStorageItem<T>(key: string, fallback: T): T {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  }

  private setStorageItem<T>(key: string, data: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error('Database write error:', e);
    }
  }

  // --- Students CRUD ---
  getStudents(): Student[] {
    return this.getStorageItem<Student[]>(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS);
  }

  registerStudent(studentData: Omit<Student, 'id' | 'createdAt'>): { success: boolean; student?: Student; error?: string } {
    const students = this.getStudents();
    
    // Check duplicates (rollNo or email)
    const exists = students.some(
      s => s.rollNo.toLowerCase() === studentData.rollNo.toLowerCase() ||
           s.email.toLowerCase() === studentData.email.toLowerCase()
    );
    if (exists) {
      return { success: false, error: 'Student with this Roll Number or Email already exists!' };
    }

    const newStudent: Student = {
      ...studentData,
      id: Date.now(),
      createdAt: new Date().toISOString().split('T')[0],
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(studentData.name)}`
    };

    students.push(newStudent);
    this.setStorageItem(STORAGE_KEYS.STUDENTS, students);
    return { success: true, student: newStudent };
  }

  loginStudent(identifier: string, password: string): { success: boolean; student?: Student; error?: string } {
    const students = this.getStudents();
    const query = identifier.trim().toLowerCase();
    const student = students.find(
      s => (s.email.toLowerCase() === query || s.rollNo.toLowerCase() === query)
    );

    if (!student) {
      return { success: false, error: 'No account found with this Roll Number or Email.' };
    }
    if (student.password !== password) {
      return { success: false, error: 'Incorrect password. Try "password123".' };
    }

    this.setCurrentStudent(student);
    return { success: true, student };
  }

  getCurrentStudent(): Student | null {
    return this.getStorageItem<Student | null>(STORAGE_KEYS.CURRENT_USER, null);
  }

  setCurrentStudent(student: Student | null): void {
    this.setStorageItem(STORAGE_KEYS.CURRENT_USER, student);
  }

  // --- Admin Authentication ---
  loginAdmin(identifier: string, password: string): { success: boolean; admin?: Admin; error?: string } {
    const query = identifier.trim().toLowerCase();
    if ((query === 'admin' || query === 'admin@smartquiz.edu') && password === 'admin123') {
      this.setCurrentAdmin(DEFAULT_ADMIN);
      return { success: true, admin: DEFAULT_ADMIN };
    }
    return { success: false, error: 'Invalid admin credentials. Use admin@smartquiz.edu / admin123' };
  }

  getCurrentAdmin(): Admin | null {
    return this.getStorageItem<Admin | null>(STORAGE_KEYS.CURRENT_ADMIN, null);
  }

  setCurrentAdmin(admin: Admin | null): void {
    this.setStorageItem(STORAGE_KEYS.CURRENT_ADMIN, admin);
  }

  logout(): void {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_ADMIN);
  }

  // --- Quizzes CRUD ---
  getQuizzes(): Quiz[] {
    return this.getStorageItem<Quiz[]>(STORAGE_KEYS.QUIZZES, INITIAL_QUIZZES);
  }

  getQuizById(id: number): Quiz | undefined {
    return this.getQuizzes().find(q => q.id === id);
  }

  createQuiz(quizData: Omit<Quiz, 'id'>): Quiz {
    const quizzes = this.getQuizzes();
    const newQuiz: Quiz = {
      ...quizData,
      id: Date.now()
    };
    quizzes.push(newQuiz);
    this.setStorageItem(STORAGE_KEYS.QUIZZES, quizzes);
    return newQuiz;
  }

  updateQuiz(id: number, updates: Partial<Quiz>): boolean {
    const quizzes = this.getQuizzes();
    const idx = quizzes.findIndex(q => q.id === id);
    if (idx === -1) return false;
    quizzes[idx] = { ...quizzes[idx], ...updates };
    this.setStorageItem(STORAGE_KEYS.QUIZZES, quizzes);
    return true;
  }

  // --- Questions CRUD ---
  getQuestions(): Question[] {
    return this.getStorageItem<Question[]>(STORAGE_KEYS.QUESTIONS, INITIAL_QUESTIONS);
  }

  getQuestionsByQuizId(quizId: number): Question[] {
    return this.getQuestions().filter(q => q.quizId === quizId);
  }

  addQuestion(questionData: Omit<Question, 'id'>): Question {
    const questions = this.getQuestions();
    const newQuestion: Question = {
      ...questionData,
      id: Date.now()
    };
    questions.push(newQuestion);
    this.setStorageItem(STORAGE_KEYS.QUESTIONS, questions);
    return newQuestion;
  }

  updateQuestion(id: number, updates: Partial<Question>): boolean {
    const questions = this.getQuestions();
    const idx = questions.findIndex(q => q.id === id);
    if (idx === -1) return false;
    questions[idx] = { ...questions[idx], ...updates };
    this.setStorageItem(STORAGE_KEYS.QUESTIONS, questions);
    return true;
  }

  deleteQuestion(id: number): boolean {
    const questions = this.getQuestions().filter(q => q.id !== id);
    this.setStorageItem(STORAGE_KEYS.QUESTIONS, questions);
    return true;
  }

  // --- Results & Submissions ---
  getResults(): QuizResult[] {
    return this.getStorageItem<QuizResult[]>(STORAGE_KEYS.RESULTS, INITIAL_RESULTS);
  }

  getResultsByStudent(studentId: number): QuizResult[] {
    return this.getResults()
      .filter(r => r.studentId === studentId)
      .sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
  }

  submitExam(
    quizId: number,
    student: Student,
    userAnswers: Record<number, 'A' | 'B' | 'C' | 'D' | null>,
    timeTakenSeconds: number
  ): QuizResult {
    const quiz = this.getQuizById(quizId);
    const questions = this.getQuestionsByQuizId(quizId);

    let correctCount = 0;
    let incorrectCount = 0;
    let attemptedCount = 0;
    let scoreObtained = 0;
    let totalMarks = 0;

    questions.forEach(q => {
      totalMarks += q.marks;
      const selected = userAnswers[q.id];
      if (selected) {
        attemptedCount++;
        if (selected === q.correctOption) {
          correctCount++;
          scoreObtained += q.marks;
        } else {
          incorrectCount++;
        }
      }
    });

    const unansweredCount = questions.length - attemptedCount;
    const percentage = totalMarks > 0 ? Math.round(((scoreObtained / totalMarks) * 100) * 10) / 10 : 0;
    const isPassed = percentage >= (quiz?.passingPercentage || 50);

    const newResult: QuizResult = {
      id: Date.now(),
      quizId,
      quizTitle: quiz?.title || 'Examination',
      studentId: student.id,
      studentName: student.name,
      studentRollNo: student.rollNo,
      totalQuestions: questions.length,
      attemptedQuestions: attemptedCount,
      correctAnswers: correctCount,
      incorrectAnswers: incorrectCount,
      unansweredQuestions: unansweredCount,
      scoreObtained,
      totalMarks,
      percentage,
      isPassed,
      timeTakenSeconds,
      submittedAt: new Date().toLocaleString(),
      answers: userAnswers
    };

    const results = this.getResults();
    results.unshift(newResult);
    this.setStorageItem(STORAGE_KEYS.RESULTS, results);

    return newResult;
  }

  // Reset database to initial test seeds
  resetToDefaults(): void {
    this.setStorageItem(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS);
    this.setStorageItem(STORAGE_KEYS.QUIZZES, INITIAL_QUIZZES);
    this.setStorageItem(STORAGE_KEYS.QUESTIONS, INITIAL_QUESTIONS);
    this.setStorageItem(STORAGE_KEYS.RESULTS, INITIAL_RESULTS);
  }
}

export const dbService = new DatabaseService();
