import { Quiz, Question, Student, QuizResult } from '../types/quiz';

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 1,
    rollNo: '21A91A0501',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@college.edu',
    password: 'password123',
    branch: 'Computer Science & Engineering',
    year: '2nd Year (2-1 Sem)',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Aarav',
    createdAt: '2026-09-15'
  },
  {
    id: 2,
    rollNo: '21A91A0542',
    name: 'Priya Patel',
    email: 'priya.patel@college.edu',
    password: 'password123',
    branch: 'Information Technology',
    year: '2nd Year (2-1 Sem)',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Priya',
    createdAt: '2026-09-18'
  }
];

export const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 1,
    title: 'Core Java & Object-Oriented Programming',
    category: 'Java Programming',
    description: 'Test your understanding of JVM architecture, OOP concepts, Polymorphism, Exception Handling, and Multithreading.',
    durationMinutes: 10,
    totalMarks: 10,
    passingPercentage: 50,
    iconName: 'Coffee',
    difficulty: 'Beginner'
  },
  {
    id: 2,
    title: 'Web Technologies & Java Servlets',
    category: 'Web Development',
    description: 'Covers HTML5 semantic tags, CSS box model, JavaScript DOM events, Servlet lifecycle, and HTTP request handling.',
    durationMinutes: 8,
    totalMarks: 10,
    passingPercentage: 50,
    iconName: 'Globe',
    difficulty: 'Intermediate'
  },
  {
    id: 3,
    title: 'Database Management Systems & SQL',
    category: 'Databases',
    description: 'Relational database schema, primary/foreign keys, normalization (1NF-3NF), SQL JOINs, and JDBC connectivity.',
    durationMinutes: 10,
    totalMarks: 10,
    passingPercentage: 50,
    iconName: 'Database',
    difficulty: 'Intermediate'
  },
  {
    id: 4,
    title: 'Data Structures & Algorithms in Java',
    category: 'Computer Science',
    description: 'Arrays, Singly/Doubly Linked Lists, Stacks, Queues, Binary Search Trees, and asymptotic Big-O notations.',
    durationMinutes: 12,
    totalMarks: 10,
    passingPercentage: 50,
    iconName: 'Layers',
    difficulty: 'Intermediate'
  },
  {
    id: 5,
    title: 'Computer Networks & Internet Protocols',
    category: 'Networking',
    description: 'OSI 7-layer model, TCP vs UDP 3-way handshakes, IP addressing, DNS resolution, and HTTP status codes.',
    durationMinutes: 8,
    totalMarks: 8,
    passingPercentage: 50,
    iconName: 'Network',
    difficulty: 'Beginner'
  }
];

export const INITIAL_QUESTIONS: Question[] = [
  // --- Quiz 1: Core Java & OOP (10 Questions) ---
  {
    id: 101,
    quizId: 1,
    questionText: 'Which component of Java is responsible for converting bytecode into machine-specific native instructions at runtime?',
    options: {
      A: 'JDK (Java Development Kit)',
      B: 'JVM (Java Virtual Machine) with JIT Compiler',
      C: 'JAVAC (Java Compiler)',
      D: 'JRE ClassLoader only'
    },
    correctOption: 'B',
    explanation: 'The JVM (Java Virtual Machine), specifically its Just-In-Time (JIT) compiler component, translates intermediate bytecode (.class) into native CPU machine code at runtime.',
    marks: 1
  },
  {
    id: 102,
    quizId: 1,
    questionText: 'What will be the output of the following Java code snippet?',
    codeSnippet: 'int x = 5;\nSystem.out.println(x++ + ++x);',
    options: {
      A: '11',
      B: '12',
      C: '10',
      D: 'Compilation Error'
    },
    correctOption: 'B',
    explanation: 'x++ evaluates to 5 and then increments x to 6. Next, ++x increments x from 6 to 7 and evaluates to 7. Therefore, 5 + 7 = 12.',
    marks: 1
  },
  {
    id: 103,
    quizId: 1,
    questionText: 'Which OOP concept is demonstrated when a subclass provides a specific implementation of a method that is already defined in its superclass?',
    options: {
      A: 'Method Overloading',
      B: 'Method Overriding (Runtime Polymorphism)',
      C: 'Data Abstraction',
      D: 'Encapsulation'
    },
    correctOption: 'B',
    explanation: 'Method Overriding occurs when a subclass defines a method with the exact same name, return type, and signature as in its parent class, achieving dynamic method dispatch at runtime.',
    marks: 1
  },
  {
    id: 104,
    quizId: 1,
    questionText: 'Which keyword in Java is used to prevent a class from being inherited and a method from being overridden?',
    options: {
      A: 'static',
      B: 'abstract',
      C: 'final',
      D: 'synchronized'
    },
    correctOption: 'C',
    explanation: 'In Java, the final keyword applied to a class prevents inheritance (e.g., class String is final), applied to a method prevents overriding, and applied to a variable makes it a constant.',
    marks: 1
  },
  {
    id: 105,
    quizId: 1,
    questionText: 'What is the default initial size of an ArrayList in Java Collections Framework when created with the default constructor?',
    options: {
      A: '0 (lazy initialization to 10 on first element addition)',
      B: '16 elements',
      C: '5 elements',
      D: '32 elements'
    },
    correctOption: 'A',
    explanation: 'In modern Java (Java 8+), new ArrayList<>() initializes an empty array instance with capacity 0, which expands to a default capacity of 10 when the first element is added.',
    marks: 1
  },
  {
    id: 106,
    quizId: 1,
    questionText: 'Which block in a Java try-catch-finally structure will execute regardless of whether an exception occurs or is caught?',
    options: {
      A: 'try block',
      B: 'catch block',
      C: 'finally block',
      D: 'throws clause'
    },
    correctOption: 'C',
    explanation: 'The finally block always executes once the try/catch blocks finish, making it ideal for cleaning up resources such as database connections, scanners, and file streams.',
    marks: 1
  },
  {
    id: 107,
    quizId: 1,
    questionText: 'Which of the following interfaces in Java does NOT extend the java.util.Collection interface?',
    options: {
      A: 'java.util.List',
      B: 'java.util.Set',
      C: 'java.util.Queue',
      D: 'java.util.Map'
    },
    correctOption: 'D',
    explanation: 'java.util.Map represents key-value pairs and does not implement the java.util.Collection interface, although it is an integral part of the Java Collections Framework.',
    marks: 1
  },
  {
    id: 108,
    quizId: 1,
    questionText: 'What is the correct way to start a new Thread in Java when implementing the Runnable interface?',
    options: {
      A: 'myRunnable.run();',
      B: 'Thread t = new Thread(myRunnable); t.start();',
      C: 'Thread t = new Thread(myRunnable); t.run();',
      D: 'myRunnable.start();'
    },
    correctOption: 'B',
    explanation: 'Calling t.start() registers the thread with the OS thread scheduler and allocates a new call stack before executing the run() method. Calling run() directly merely executes it in the current main thread.',
    marks: 1
  },
  {
    id: 109,
    quizId: 1,
    questionText: 'Where are Java objects created using the "new" keyword allocated in memory?',
    options: {
      A: 'Stack Memory',
      B: 'Heap Memory',
      C: 'Registers',
      D: 'Method Area only'
    },
    correctOption: 'B',
    explanation: 'All object instances and arrays in Java are dynamically allocated in the Heap memory, managed by the automatic Garbage Collector.',
    marks: 1
  },
  {
    id: 110,
    quizId: 1,
    questionText: 'Which access modifier allows access within the same package and by subclasses even if they are in different packages?',
    options: {
      A: 'public',
      B: 'protected',
      C: 'default (package-private)',
      D: 'private'
    },
    correctOption: 'B',
    explanation: 'The protected access specifier gives visibility within the same package plus child classes (inheritance) located in external packages.',
    marks: 1
  },

  // --- Quiz 2: Web Technologies & Java Servlets (10 Questions) ---
  {
    id: 201,
    quizId: 2,
    questionText: 'Which method in the Java Servlet lifecycle is invoked only ONCE when the servlet container loads the servlet into memory?',
    options: {
      A: 'service(ServletRequest, ServletResponse)',
      B: 'init(ServletConfig)',
      C: 'doGet(HttpServletRequest, HttpServletResponse)',
      D: 'destroy()'
    },
    correctOption: 'B',
    explanation: 'init(ServletConfig config) is executed exactly once by the servlet container (such as Apache Tomcat) during servlet initialization to configure resources.',
    marks: 1
  },
  {
    id: 202,
    quizId: 2,
    questionText: 'In Apache Tomcat, where is the standard deployment descriptor file (web.xml) located relative to the web application root folder?',
    options: {
      A: 'META-INF/web.xml',
      B: 'WEB-INF/web.xml',
      C: 'src/main/resources/web.xml',
      D: 'WebContent/web.xml'
    },
    correctOption: 'B',
    explanation: 'In Java Web applications, the deployment descriptor web.xml is mandatory under the WEB-INF/ directory, which is protected from direct public HTTP access.',
    marks: 1
  },
  {
    id: 203,
    quizId: 2,
    questionText: 'Which HTTP method should be preferred for submitting sensitive credentials like user passwords in an HTML form?',
    options: {
      A: 'GET (parameters visible in URL query string)',
      B: 'POST (parameters sent inside HTTP request body)',
      C: 'HEAD',
      D: 'OPTIONS'
    },
    correctOption: 'B',
    explanation: 'HTTP POST encapsulates form data within the HTTP payload body rather than appending cleartext query strings in the browser URL bar or server access logs.',
    marks: 1
  },
  {
    id: 204,
    quizId: 2,
    questionText: 'What is the key difference between request.getRequestDispatcher().forward() and response.sendRedirect() in Java Servlets?',
    options: {
      A: 'forward() is client-side; sendRedirect() is server-side',
      B: 'forward() happens entirely on the server preserving request attributes; sendRedirect() issues HTTP 302 to the browser',
      C: 'forward() changes the browser address bar URL; sendRedirect() does not',
      D: 'sendRedirect() can only navigate within the same web application'
    },
    correctOption: 'B',
    explanation: 'RequestDispatcher.forward() routes requests internally on the Tomcat server with 1 roundtrip, retaining request attributes. sendRedirect() instructs the client browser with an HTTP 302 code to make a fresh GET request.',
    marks: 1
  },
  {
    id: 205,
    quizId: 2,
    questionText: 'Which JavaScript method is used to schedule a function to run repeatedly at a specified time interval (such as updating a countdown timer)?',
    options: {
      A: 'setTimeout()',
      B: 'setInterval()',
      C: 'requestAnimationFrame() only',
      D: 'setCountdown()'
    },
    correctOption: 'B',
    explanation: 'setInterval(callback, delayMs) repeatedly executes the specified callback function every delay milliseconds until cancelled by clearInterval().',
    marks: 1
  },
  {
    id: 206,
    quizId: 2,
    questionText: 'Which session tracking mechanism in Java Servlets uses a temporary cookie named JSESSIONID stored on the client browser?',
    options: {
      A: 'URL Rewriting',
      B: 'HttpSession API',
      C: 'Hidden Form Fields',
      D: 'HTML5 Web Storage'
    },
    correctOption: 'B',
    explanation: 'The request.getSession() API creates an HttpSession tracked automatically via the JSESSIONID cookie exchanged between the client and Tomcat.',
    marks: 1
  },
  {
    id: 207,
    quizId: 2,
    questionText: 'Which CSS property is used in modern layouts to arrange items along a primary horizontal or vertical axis with flexible spacing?',
    options: {
      A: 'display: block',
      B: 'display: flex',
      C: 'float: left',
      D: 'position: absolute'
    },
    correctOption: 'B',
    explanation: 'Flexbox (display: flex) provides flexible 1-dimensional layout alignment along either row or column axes.',
    marks: 1
  },
  {
    id: 208,
    quizId: 2,
    questionText: 'What does the HTTP 404 status code signify in web architecture?',
    options: {
      A: 'Internal Server Error',
      B: 'Unauthorized Access',
      C: 'Requested Resource Not Found',
      D: 'Bad Gateway'
    },
    correctOption: 'C',
    explanation: 'HTTP status 404 indicates that the web server cannot find the requested URL resource (page, servlet mapping, or static asset).',
    marks: 1
  },
  {
    id: 209,
    quizId: 2,
    questionText: 'In a Java Servlet, which method is called to read an incoming form input parameter named "username"?',
    options: {
      A: 'request.getAttribute("username")',
      B: 'request.getParameter("username")',
      C: 'response.getParameter("username")',
      D: 'session.getParameter("username")'
    },
    correctOption: 'B',
    explanation: 'request.getParameter("paramName") returns the String value of the specified HTTP query parameter or POST form field.',
    marks: 1
  },
  {
    id: 210,
    quizId: 2,
    questionText: 'Which HTML5 semantic element is most appropriate for grouping introductory navigation links?',
    options: {
      A: '<section>',
      B: '<nav>',
      C: '<aside>',
      D: '<div>'
    },
    correctOption: 'B',
    explanation: 'The <nav> element represents a section of a page whose purpose is to provide navigation links, either within the current document or to other documents.',
    marks: 1
  },

  // --- Quiz 3: DBMS & SQL (10 Questions) ---
  {
    id: 301,
    quizId: 3,
    questionText: 'Which JDBC interface is used to execute pre-compiled SQL queries with parameterized "?" placeholders to prevent SQL Injection?',
    options: {
      A: 'java.sql.Statement',
      B: 'java.sql.PreparedStatement',
      C: 'java.sql.CallableStatement',
      D: 'java.sql.ResultSet'
    },
    correctOption: 'B',
    explanation: 'PreparedStatement compiles the SQL query template on the database server upfront and uses placeholder setters (setString, setInt), immunizing against SQL Injection attacks.',
    marks: 1
  },
  {
    id: 302,
    quizId: 3,
    questionText: 'Which SQL clause is used to filter aggregated group records produced by a GROUP BY statement?',
    options: {
      A: 'WHERE',
      B: 'HAVING',
      C: 'ORDER BY',
      D: 'LIMIT'
    },
    correctOption: 'B',
    explanation: 'WHERE filters individual table rows prior to aggregation, while HAVING filters the computed aggregates after the GROUP BY operation.',
    marks: 1
  },
  {
    id: 303,
    quizId: 3,
    questionText: 'In relational database normalization, what condition must a table satisfy to be in Second Normal Form (2NF)?',
    options: {
      A: 'It must contain no duplicate rows.',
      B: 'It must be in 1NF and have no partial functional dependencies on a composite primary key.',
      C: 'It must have no transitive dependencies.',
      D: 'All columns must have numeric datatypes.'
    },
    correctOption: 'B',
    explanation: '2NF requires 1NF compliance plus ensuring that every non-key column is fully dependent on the whole primary key, eliminating partial key dependencies.',
    marks: 1
  },
  {
    id: 304,
    quizId: 3,
    questionText: 'Which SQL JOIN returns all rows from the left table and only matching rows from the right table, filling non-matches with NULL?',
    options: {
      A: 'INNER JOIN',
      B: 'LEFT OUTER JOIN',
      C: 'FULL OUTER JOIN',
      D: 'CROSS JOIN'
    },
    correctOption: 'B',
    explanation: 'LEFT JOIN returns all tuples from the left-hand table, pairing them with right table attributes if matching criteria are met, or NULL otherwise.',
    marks: 1
  },
  {
    id: 305,
    quizId: 3,
    questionText: 'What is the correct driver class name for the MySQL 8.x Connector/J driver used in Class.forName()?',
    options: {
      A: 'org.gjt.mm.mysql.Driver',
      B: 'com.mysql.cj.jdbc.Driver',
      C: 'com.mysql.jdbc.Driver (deprecated in 8.0+)',
      D: 'jdbc.mysql.Driver'
    },
    correctOption: 'B',
    explanation: 'com.mysql.cj.jdbc.Driver is the official driver class for MySQL Connector/J 8.0 and above.',
    marks: 1
  },
  {
    id: 306,
    quizId: 3,
    questionText: 'What does the "A" in ACID database transaction properties stand for?',
    options: {
      A: 'Availability',
      B: 'Atomicity',
      C: 'Authentication',
      D: 'Asynchronous'
    },
    correctOption: 'B',
    explanation: 'Atomicity guarantees that all statements within a transaction either execute completely or roll back entirely ("all or nothing").',
    marks: 1
  },
  {
    id: 307,
    quizId: 3,
    questionText: 'Which SQL command is classified as Data Definition Language (DDL)?',
    options: {
      A: 'SELECT',
      B: 'INSERT',
      C: 'CREATE TABLE',
      D: 'UPDATE'
    },
    correctOption: 'C',
    explanation: 'DDL commands define the structure or schema of the database, including CREATE, ALTER, DROP, and TRUNCATE.',
    marks: 1
  },
  {
    id: 308,
    quizId: 3,
    questionText: 'In a JDBC ResultSet, which method is invoked to advance the cursor to the next row of data?',
    options: {
      A: 'rs.first()',
      B: 'rs.next()',
      C: 'rs.move()',
      D: 'rs.fetch()'
    },
    correctOption: 'B',
    explanation: 'rs.next() advances the cursor to the subsequent row, returning true if a valid row exists or false when no more records remain.',
    marks: 1
  },
  {
    id: 309,
    quizId: 3,
    questionText: 'Which constraint ensures that no duplicate values exist in a column and also does not allow NULL values?',
    options: {
      A: 'FOREIGN KEY',
      B: 'UNIQUE constraint',
      C: 'PRIMARY KEY',
      D: 'CHECK constraint'
    },
    correctOption: 'C',
    explanation: 'A PRIMARY KEY uniquely identifies each record in a table, inherently enforcing both UNIQUE and NOT NULL constraints.',
    marks: 1
  },
  {
    id: 310,
    quizId: 3,
    questionText: 'Which SQL statement permanently saves changes made during the current database transaction?',
    options: {
      A: 'SAVEPOINT',
      B: 'ROLLBACK',
      C: 'COMMIT',
      D: 'FLUSH'
    },
    correctOption: 'C',
    explanation: 'COMMIT makes all structural and data modifications performed within the active transaction permanent in the database storage engine.',
    marks: 1
  },

  // --- Quiz 4: Data Structures & Algorithms (10 Questions) ---
  {
    id: 401,
    quizId: 4,
    questionText: 'What is the worst-case time complexity of searching for an element in an unsorted array of size N?',
    options: {
      A: 'O(1)',
      B: 'O(log N)',
      C: 'O(N)',
      D: 'O(N²)'
    },
    correctOption: 'C',
    explanation: 'In an unsorted array, linear search must examine every element in the worst case (when the target is at the end or absent), taking O(N) comparisons.',
    marks: 1
  },
  {
    id: 402,
    quizId: 4,
    questionText: 'Which data structure operates strictly on the Last-In, First-Out (LIFO) access principle?',
    options: {
      A: 'Queue',
      B: 'Stack',
      C: 'Binary Tree',
      D: 'Priority Queue'
    },
    correctOption: 'B',
    explanation: 'A Stack follows the Last-In, First-Out (LIFO) rule, commonly used for function call stacks, parenthesis matching, and undo/redo operations.',
    marks: 1
  },
  {
    id: 403,
    quizId: 4,
    questionText: 'In a Singly Linked List, what is the time complexity to insert a new node at the very beginning (head) of the list?',
    options: {
      A: 'O(1) constant time',
      B: 'O(N) linear time',
      C: 'O(log N)',
      D: 'O(N log N)'
    },
    correctOption: 'A',
    explanation: 'Inserting at the head merely requires setting newNode.next = head and updating head = newNode, which requires O(1) constant pointer updates.',
    marks: 1
  },
  {
    id: 404,
    quizId: 4,
    questionText: 'What is the average time complexity of QuickSort on an array of size N?',
    options: {
      A: 'O(N)',
      B: 'O(N log N)',
      C: 'O(N²)',
      D: 'O(log N)'
    },
    correctOption: 'B',
    explanation: 'QuickSort divides the array around a pivot element. In average cases with reasonably balanced partitions, it achieves O(N log N) time complexity.',
    marks: 1
  },
  {
    id: 405,
    quizId: 4,
    questionText: 'In a Binary Search Tree (BST), where are keys smaller than the root node stored?',
    options: {
      A: 'In the right subtree',
      B: 'In the left subtree',
      C: 'Randomly anywhere in the tree',
      D: 'At the root node only'
    },
    correctOption: 'B',
    explanation: 'By definition of a BST, all nodes in the left subtree possess keys strictly less than the root node, and all nodes in the right subtree possess keys greater.',
    marks: 1
  },
  {
    id: 406,
    quizId: 4,
    questionText: 'Which graph traversal algorithm uses a Queue data structure to explore vertices level by level?',
    options: {
      A: 'Depth-First Search (DFS)',
      B: 'Breadth-First Search (BFS)',
      C: 'Dijkstra Algorithm without queue',
      D: 'Prim Minimal Spanning Tree'
    },
    correctOption: 'B',
    explanation: 'BFS uses a FIFO Queue to visit neighbors before progressing to subsequent concentric depth levels.',
    marks: 1
  },
  {
    id: 407,
    quizId: 4,
    questionText: 'What condition causes a Stack Overflow error in a recursive function?',
    options: {
      A: 'Allocating too many objects in Heap memory',
      B: 'Missing or never-reached base condition causing infinite call frames on the Call Stack',
      C: 'Using arrays with negative indexes',
      D: 'Dereferencing a null pointer'
    },
    correctOption: 'B',
    explanation: 'Each recursive call consumes a stack frame. Without a valid base case, calls continue indefinitely until JVM stack memory is exhausted.',
    marks: 1
  },
  {
    id: 408,
    quizId: 4,
    questionText: 'What is the primary advantage of a Doubly Linked List over a Singly Linked List?',
    options: {
      A: 'Requires less memory per node',
      B: 'Allows bi-directional traversal (forward and backward) and O(1) deletion given the target node pointer',
      C: 'Provides faster O(1) random index access like an array',
      D: 'Prevents null pointer exceptions'
    },
    correctOption: 'B',
    explanation: 'Each node maintains both next and prev pointers, allowing seamless two-way navigation and O(1) node deletion without traversing from head.',
    marks: 1
  },
  {
    id: 409,
    quizId: 4,
    questionText: 'Which collision resolution technique in Hash Tables stores colliding elements in a linked list at the hashed bucket index?',
    options: {
      A: 'Linear Probing',
      B: 'Quadratic Probing',
      C: 'Separate Chaining',
      D: 'Double Hashing'
    },
    correctOption: 'C',
    explanation: 'Separate Chaining maintains an auxiliary linked list (or balanced red-black tree in Java 8+ HashMap) at each bucket index to hold collisions.',
    marks: 1
  },
  {
    id: 410,
    quizId: 4,
    questionText: 'What is the minimum number of queues required to implement a Stack data structure?',
    options: {
      A: '1 queue',
      B: '2 queues',
      C: '3 queues',
      D: '4 queues'
    },
    correctOption: 'B',
    explanation: 'Standard queue-based stack implementation requires 2 FIFO queues to invert the order and simulate LIFO behavior (though can be optimized with 1 queue using circular rotations).',
    marks: 1
  },

  // --- Quiz 5: Computer Networks (8 Questions) ---
  {
    id: 501,
    quizId: 5,
    questionText: 'In the OSI 7-layer reference model, at which layer do Routers primarily operate based on IP addresses?',
    options: {
      A: 'Physical Layer (Layer 1)',
      B: 'Data Link Layer (Layer 2)',
      C: 'Network Layer (Layer 3)',
      D: 'Transport Layer (Layer 4)'
    },
    correctOption: 'C',
    explanation: 'Routers operate at Network Layer (Layer 3), inspecting logical IP addresses to forward packets across distinct network segments.',
    marks: 1
  },
  {
    id: 502,
    quizId: 5,
    questionText: 'Which protocol is connection-oriented, provides guaranteed in-order packet delivery, and utilizes a 3-way handshake?',
    options: {
      A: 'UDP (User Datagram Protocol)',
      B: 'TCP (Transmission Control Protocol)',
      C: 'ICMP (Internet Control Message Protocol)',
      D: 'ARP (Address Resolution Protocol)'
    },
    correctOption: 'B',
    explanation: 'TCP establishes a reliable virtual circuit via SYN -> SYN-ACK -> ACK handshaking, with automatic sequence numbers, acknowledgements, and retransmissions.',
    marks: 1
  },
  {
    id: 503,
    quizId: 5,
    questionText: 'What is the default TCP port number used by HTTPS (Hypertext Transfer Protocol Secure) connections?',
    options: {
      A: '21',
      B: '80',
      C: '443',
      D: '8080'
    },
    correctOption: 'C',
    explanation: 'Port 443 is the standard port for TLS/SSL encrypted HTTPS traffic, while plain HTTP uses port 80.',
    marks: 1
  },
  {
    id: 504,
    quizId: 5,
    questionText: 'Which protocol is responsible for mapping a known 32-bit IPv4 address to a physical 48-bit MAC address on a local area network?',
    options: {
      A: 'DNS',
      B: 'DHCP',
      C: 'ARP (Address Resolution Protocol)',
      D: 'BGP'
    },
    correctOption: 'C',
    explanation: 'ARP broadcasts on the local layer-2 Ethernet network to identify which device hardware MAC address owns a given IP address.',
    marks: 1
  },
  {
    id: 505,
    quizId: 5,
    questionText: 'What is the total bit length of an IPv6 address compared to an IPv4 address?',
    options: {
      A: '32 bits vs 16 bits',
      B: '128 bits vs 32 bits',
      C: '64 bits vs 32 bits',
      D: '256 bits vs 64 bits'
    },
    correctOption: 'B',
    explanation: 'IPv6 uses 128-bit addresses (represented in 8 groups of 4 hexadecimal digits), whereas IPv4 uses 32-bit addresses in 4 octets.',
    marks: 1
  },
  {
    id: 506,
    quizId: 5,
    questionText: 'Which application layer protocol automatically assigns dynamic IP addresses, default gateways, and DNS servers to client devices?',
    options: {
      A: 'DNS',
      B: 'DHCP (Dynamic Host Configuration Protocol)',
      C: 'SNMP',
      D: 'FTP'
    },
    correctOption: 'B',
    explanation: 'DHCP operates via DORA (Discover, Offer, Request, Acknowledge) to lease IP configuration parameters automatically to network nodes.',
    marks: 1
  },
  {
    id: 507,
    quizId: 5,
    questionText: 'Which protocol is favored for real-time video streaming and multiplayer gaming where low latency is preferred over packet loss recovery?',
    options: {
      A: 'TCP',
      B: 'UDP',
      C: 'SSH',
      D: 'SMTP'
    },
    correctOption: 'B',
    explanation: 'UDP is a connectionless, lightweight protocol with zero retransmission overhead, prioritizing minimal delay over lossless transmission.',
    marks: 1
  },
  {
    id: 508,
    quizId: 5,
    questionText: 'What is the function of the Subnet Mask in IP networking (e.g., 255.255.255.0 or /24)?',
    options: {
      A: 'To encrypt IP packets on the wire',
      B: 'To distinguish the Network ID portion from the Host ID portion of an IP address',
      C: 'To assign port numbers to web servers',
      D: 'To determine physical Wi-Fi signal strength'
    },
    correctOption: 'B',
    explanation: 'Bitwise ANDing an IP address with its Subnet Mask reveals the network boundary prefix (Network portion) versus individual node identifier (Host portion).',
    marks: 1
  }
];

export const INITIAL_RESULTS: QuizResult[] = [
  {
    id: 1001,
    quizId: 1,
    quizTitle: 'Core Java & Object-Oriented Programming',
    studentId: 1,
    studentName: 'Aarav Sharma',
    studentRollNo: '21A91A0501',
    totalQuestions: 10,
    attemptedQuestions: 10,
    correctAnswers: 9,
    incorrectAnswers: 1,
    unansweredQuestions: 0,
    scoreObtained: 9,
    totalMarks: 10,
    percentage: 90,
    isPassed: true,
    timeTakenSeconds: 342,
    submittedAt: '2026-11-06 14:22:10',
    answers: { 101: 'B', 102: 'B', 103: 'B', 104: 'C', 105: 'A', 106: 'C', 107: 'D', 108: 'B', 109: 'B', 110: 'B' }
  },
  {
    id: 1002,
    quizId: 2,
    quizTitle: 'Web Technologies & Java Servlets',
    studentId: 1,
    studentName: 'Aarav Sharma',
    studentRollNo: '21A91A0501',
    totalQuestions: 10,
    attemptedQuestions: 9,
    correctAnswers: 8,
    incorrectAnswers: 1,
    unansweredQuestions: 1,
    scoreObtained: 8,
    totalMarks: 10,
    percentage: 80,
    isPassed: true,
    timeTakenSeconds: 280,
    submittedAt: '2026-11-07 10:15:45',
    answers: { 201: 'B', 202: 'B', 203: 'B', 204: 'B', 205: 'B', 206: 'B', 207: 'B', 208: 'C', 209: 'B', 210: null }
  }
];
