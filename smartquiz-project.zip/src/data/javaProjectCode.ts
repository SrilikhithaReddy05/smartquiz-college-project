export interface JavaFile {
  name: string;
  category: 'java' | 'sql' | 'config' | 'guide';
  path: string;
  description: string;
  code: string;
}

export const JAVA_PROJECT_FILES: JavaFile[] = [
  {
    name: 'smartquiz.sql',
    category: 'sql',
    path: 'database/smartquiz.sql',
    description: 'Complete MySQL Database DDL & DML Schema with tables for students, admins, quizzes, questions, quiz_results, and student_answers.',
    code: `-- ========================================================
-- SmartQuiz: Interactive Quiz Website with Live Countdown Timer
-- Database Name: smartquiz
-- College Mini Project for 2-1 Semester B.Tech (CSE / IT)
-- ========================================================

DROP DATABASE IF EXISTS smartquiz;
CREATE DATABASE smartquiz CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartquiz;

-- 1. Students Table
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    roll_no VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    branch VARCHAR(50) NOT NULL,
    year_sem VARCHAR(20) DEFAULT '2-1',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Admins Table
CREATE TABLE admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'SUPER_ADMIN'
);

-- 3. Quizzes Table
CREATE TABLE quizzes (
    quiz_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT,
    duration_minutes INT NOT NULL DEFAULT 10,
    total_marks INT NOT NULL DEFAULT 10,
    passing_percentage INT NOT NULL DEFAULT 50,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Questions Table
CREATE TABLE questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT NOT NULL,
    question_text TEXT NOT NULL,
    code_snippet TEXT,
    option_a VARCHAR(255) NOT NULL,
    option_b VARCHAR(255) NOT NULL,
    option_c VARCHAR(255) NOT NULL,
    option_d VARCHAR(255) NOT NULL,
    correct_option CHAR(1) NOT NULL, -- 'A', 'B', 'C', 'D'
    explanation TEXT,
    marks INT DEFAULT 1,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id) ON DELETE CASCADE
);

-- 5. Quiz Results Table
CREATE TABLE quiz_results (
    result_id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT NOT NULL,
    student_id INT NOT NULL,
    total_questions INT NOT NULL,
    attempted_questions INT NOT NULL,
    correct_answers INT NOT NULL,
    incorrect_answers INT NOT NULL,
    unanswered_questions INT NOT NULL,
    score_obtained INT NOT NULL,
    total_marks INT NOT NULL,
    percentage DECIMAL(5,2) NOT NULL,
    is_passed BOOLEAN NOT NULL,
    time_taken_seconds INT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- 6. Student Answers Detail Table
CREATE TABLE student_answers (
    answer_id INT AUTO_INCREMENT PRIMARY KEY,
    result_id INT NOT NULL,
    question_id INT NOT NULL,
    selected_option CHAR(1), -- 'A', 'B', 'C', 'D' or NULL
    is_correct BOOLEAN NOT NULL,
    FOREIGN KEY (result_id) REFERENCES quiz_results(result_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
);

-- ========================================================
-- Seed Initial Records
-- ========================================================

-- Insert Sample Admin
INSERT INTO admins (username, full_name, email, password, role) 
VALUES ('admin', 'Prof. Head of Dept', 'admin@smartquiz.edu', 'admin123', 'EXAM_COORDINATOR');

-- Insert Sample Students
INSERT INTO students (roll_no, full_name, email, password, branch, year_sem) 
VALUES 
('21A91A0501', 'Aarav Sharma', 'aarav.sharma@college.edu', 'password123', 'CSE', '2-1'),
('21A91A0542', 'Priya Patel', 'priya.patel@college.edu', 'password123', 'IT', '2-1');

-- Insert Quizzes
INSERT INTO quizzes (quiz_id, title, category, description, duration_minutes, total_marks, passing_percentage) 
VALUES 
(1, 'Core Java & OOP Concepts', 'Java', 'Fundamentals of JVM, Overriding, Multithreading, and Collections.', 10, 10, 50),
(2, 'Web Technologies & Servlets', 'Web Tech', 'HTML5, CSS, JS events, and Java Servlet lifecycle.', 8, 10, 50),
(3, 'DBMS & SQL Mastery', 'Databases', 'Relational schema, SQL queries, normalization, and ACID.', 10, 10, 50);

-- Insert Sample Questions for Quiz 1 (Core Java)
INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, marks)
VALUES
(1, 'Which component converts bytecode into machine code at runtime?', 'JDK', 'JVM with JIT Compiler', 'JAVAC', 'ClassLoader only', 'B', 'JVM JIT compiler translates bytecode into native CPU instructions at runtime.', 1),
(1, 'Which keyword prevents a class from being subclassed in Java?', 'static', 'abstract', 'final', 'synchronized', 'C', 'Applying final to a class prevents inheritance.', 1),
(1, 'Where are dynamically instantiated objects stored in Java memory?', 'Stack', 'Heap', 'CPU Registers', 'Method Area', 'B', 'All Java objects allocated with new reside in Heap memory.', 1),
(1, 'Which block executes regardless of whether an exception occurs?', 'try block', 'catch block', 'finally block', 'throws clause', 'C', 'finally block always runs after try/catch for resource cleanup.', 1);
`
  },
  {
    name: 'DBConnection.java',
    category: 'java',
    path: 'src/com/smartquiz/util/DBConnection.java',
    description: 'Singleton JDBC Database Connection Manager to connect Servlets to MySQL.',
    code: `package com.smartquiz.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection.java
 * Purpose: Manages JDBC connection lifecycle to MySQL smartquiz database.
 * College: B.Tech 2-1 Semester Mini Project
 */
public class DBConnection {

    // Database credentials (adjust port and password as per local MySQL setup)
    private static final String URL = "jdbc:mysql://localhost:3306/smartquiz?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "root"; // Or your MySQL password
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    // Static block loads JDBC Driver once during class loading
    static {
        try {
            Class.forName(DRIVER);
            System.out.println("[DBConnection] MySQL 8.x Driver Loaded Successfully.");
        } catch (ClassNotFoundException e) {
            System.err.println("[DBConnection] Error: MySQL JDBC Driver not found!");
            e.printStackTrace();
        }
    }

    /**
     * Obtains a fresh active database connection.
     * @return Connection object
     * @throws SQLException
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /**
     * Safely closes resources to avoid database connection leaks.
     */
    public static void close(AutoCloseable... resources) {
        for (AutoCloseable res : resources) {
            if (res != null) {
                try {
                    res.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
`
  },
  {
    name: 'LoginServlet.java',
    category: 'java',
    path: 'src/com/smartquiz/controller/LoginServlet.java',
    description: 'Handles Student & Admin authentication, creates HttpSession, and routes to respective dashboards.',
    code: `package com.smartquiz.controller;

import com.smartquiz.util.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * LoginServlet.java
 * Handles both student and admin login via PreparedStatement.
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String identifier = request.getParameter("identifier"); // email or rollNo
        String password = request.getParameter("password");
        String role = request.getParameter("role"); // "student" or "admin"

        if (identifier == null || password == null || identifier.trim().isEmpty()) {
            response.sendRedirect("login.jsp?error=EmptyCredentials");
            return;
        }

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();

            if ("admin".equalsIgnoreCase(role)) {
                // Admin Authentication
                String sql = "SELECT admin_id, username, full_name, email FROM admins WHERE (email = ? OR username = ?) AND password = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, identifier.trim());
                ps.setString(2, identifier.trim());
                ps.setString(3, password.trim());
                rs = ps.executeQuery();

                if (rs.next()) {
                    HttpSession session = request.getSession(true);
                    session.setAttribute("userRole", "admin");
                    session.setAttribute("adminId", rs.getInt("admin_id"));
                    session.setAttribute("adminName", rs.getString("full_name"));
                    response.sendRedirect("admin-dashboard.jsp");
                    return;
                }
            } else {
                // Student Authentication
                String sql = "SELECT student_id, roll_no, full_name, email, branch FROM students WHERE (email = ? OR roll_no = ?) AND password = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, identifier.trim());
                ps.setString(2, identifier.trim());
                ps.setString(3, password.trim());
                rs = ps.executeQuery();

                if (rs.next()) {
                    HttpSession session = request.getSession(true);
                    session.setAttribute("userRole", "student");
                    session.setAttribute("studentId", rs.getInt("student_id"));
                    session.setAttribute("rollNo", rs.getString("roll_no"));
                    session.setAttribute("studentName", rs.getString("full_name"));
                    session.setAttribute("branch", rs.getString("branch"));
                    response.sendRedirect("student-dashboard.jsp");
                    return;
                }
            }

            // Authentication failure
            response.sendRedirect("login.jsp?error=InvalidCredentials");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp?error=DatabaseError");
        } finally {
            DBConnection.close(rs, ps, conn);
        }
    }
}
`
  },
  {
    name: 'RegisterServlet.java',
    category: 'java',
    path: 'src/com/smartquiz/controller/RegisterServlet.java',
    description: 'Registers new students into MySQL students table with form validation.',
    code: `package com.smartquiz.controller;

import com.smartquiz.util.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * RegisterServlet.java
 * Validates student details and stores them in MySQL database.
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String rollNo = request.getParameter("rollNo");
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String branch = request.getParameter("branch");
        String yearSem = request.getParameter("yearSem");

        // Basic server-side validation
        if (rollNo == null || fullName == null || email == null || password == null) {
            response.sendRedirect("register.jsp?error=MissingFields");
            return;
        }

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            String sql = "INSERT INTO students (roll_no, full_name, email, password, branch, year_sem) VALUES (?, ?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, rollNo.trim().toUpperCase());
            ps.setString(2, fullName.trim());
            ps.setString(3, email.trim().toLowerCase());
            ps.setString(4, password.trim());
            ps.setString(5, branch != null ? branch.trim() : "CSE");
            ps.setString(6, yearSem != null ? yearSem.trim() : "2-1");

            int rows = ps.executeUpdate();
            if (rows > 0) {
                response.sendRedirect("login.jsp?registered=success");
            } else {
                response.sendRedirect("register.jsp?error=Failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Typically happens if roll_no or email violates UNIQUE constraint
            response.sendRedirect("register.jsp?error=DuplicateEntry");
        } finally {
            DBConnection.close(ps, conn);
        }
    }
}
`
  },
  {
    name: 'SubmitQuizServlet.java',
    category: 'java',
    path: 'src/com/smartquiz/controller/SubmitQuizServlet.java',
    description: 'Evaluates student answers, calculates marks, records attempt in quiz_results and student_answers, and forwards to result.jsp.',
    code: `package com.smartquiz.controller;

import com.smartquiz.util.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * SubmitQuizServlet.java
 * Purpose: Evaluates quiz answers dynamically from MySQL and stores results.
 * Handles both manual submission and automated timeout submission.
 */
@WebServlet("/SubmitQuizServlet")
public class SubmitQuizServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("studentId") == null) {
            response.sendRedirect("login.jsp?error=SessionExpired");
            return;
        }

        int studentId = (Integer) session.getAttribute("studentId");
        int quizId = Integer.parseInt(request.getParameter("quizId"));
        int timeTakenSeconds = Integer.parseInt(request.getParameter("timeTakenSeconds"));

        // Extract student choices: format question_101=B
        Map<Integer, String> studentAnswers = new HashMap<>();
        Enumeration<String> paramNames = request.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String param = paramNames.nextElement();
            if (param.startsWith("q_")) {
                int qId = Integer.parseInt(param.substring(2));
                String selected = request.getParameter(param);
                if (selected != null && !selected.trim().isEmpty()) {
                    studentAnswers.put(qId, selected.trim().toUpperCase());
                }
            }
        }

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // Begin ACID Transaction

            // 1. Fetch correct answers from questions table
            String fetchSql = "SELECT question_id, correct_option, marks FROM questions WHERE quiz_id = ?";
            ps = conn.prepareStatement(fetchSql);
            ps.setInt(1, quizId);
            rs = ps.executeQuery();

            int totalQuestions = 0;
            int attempted = 0;
            int correct = 0;
            int incorrect = 0;
            int scoreObtained = 0;
            int totalMarks = 0;

            Map<Integer, Boolean> correctnessMap = new HashMap<>();

            while (rs.next()) {
                totalQuestions++;
                int qId = rs.getInt("question_id");
                String correctOpt = rs.getString("correct_option");
                int marks = rs.getInt("marks");
                totalMarks += marks;

                if (studentAnswers.containsKey(qId)) {
                    attempted++;
                    String chosen = studentAnswers.get(qId);
                    if (correctOpt.equalsIgnoreCase(chosen)) {
                        correct++;
                        scoreObtained += marks;
                        correctnessMap.put(qId, true);
                    } else {
                        incorrect++;
                        correctnessMap.put(qId, false);
                    }
                } else {
                    correctnessMap.put(qId, false);
                }
            }
            int unanswered = totalQuestions - attempted;
            double percentage = totalMarks > 0 ? ((double) scoreObtained / totalMarks) * 100.0 : 0.0;
            boolean isPassed = percentage >= 50.0;

            // 2. Insert into quiz_results table
            String insertResultSql = "INSERT INTO quiz_results " +
                "(quiz_id, student_id, total_questions, attempted_questions, correct_answers, incorrect_answers, " +
                "unanswered_questions, score_obtained, total_marks, percentage, is_passed, time_taken_seconds) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            ps = conn.prepareStatement(insertResultSql, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, quizId);
            ps.setInt(2, studentId);
            ps.setInt(3, totalQuestions);
            ps.setInt(4, attempted);
            ps.setInt(5, correct);
            ps.setInt(6, incorrect);
            ps.setInt(7, unanswered);
            ps.setInt(8, scoreObtained);
            ps.setInt(9, totalMarks);
            ps.setDouble(10, Math.round(percentage * 100.0) / 100.0);
            ps.setBoolean(11, isPassed);
            ps.setInt(12, timeTakenSeconds);
            ps.executeUpdate();

            rs = ps.getGeneratedKeys();
            int resultId = 0;
            if (rs.next()) {
                resultId = rs.getInt(1);
            }

            // 3. Insert individual question responses into student_answers table
            String insertAnswerSql = "INSERT INTO student_answers (result_id, question_id, selected_option, is_correct) VALUES (?, ?, ?, ?)";
            ps = conn.prepareStatement(insertAnswerSql);
            for (Map.Entry<Integer, String> entry : studentAnswers.entrySet()) {
                ps.setInt(1, resultId);
                ps.setInt(2, entry.getKey());
                ps.setString(3, entry.getValue());
                ps.setBoolean(4, correctnessMap.getOrDefault(entry.getKey(), false));
                ps.addBatch();
            }
            ps.executeBatch();

            conn.commit(); // Commit transaction

            // Redirect to result page with result ID
            response.sendRedirect("result.jsp?resultId=" + resultId);

        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (Exception ex) { ex.printStackTrace(); }
            }
            e.printStackTrace();
            response.sendRedirect("student-dashboard.jsp?error=SubmissionFailed");
        } finally {
            DBConnection.close(rs, ps, conn);
        }
    }
}
`
  },
  {
    name: 'AdminQuestionServlet.java',
    category: 'java',
    path: 'src/com/smartquiz/controller/AdminQuestionServlet.java',
    description: 'Admin Servlet for adding, editing, and deleting questions from the MySQL question bank.',
    code: `package com.smartquiz.controller;

import com.smartquiz.util.DBConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * AdminQuestionServlet.java
 * CRUD operations for examination questions.
 */
@WebServlet("/AdminQuestionServlet")
public class AdminQuestionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equals(session.getAttribute("userRole"))) {
            response.sendRedirect("login.jsp?error=Unauthorized");
            return;
        }

        String action = request.getParameter("action"); // "add", "edit", "delete"
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();

            if ("add".equalsIgnoreCase(action)) {
                int quizId = Integer.parseInt(request.getParameter("quizId"));
                String qText = request.getParameter("questionText");
                String optA = request.getParameter("optionA");
                String optB = request.getParameter("optionB");
                String optC = request.getParameter("optionC");
                String optD = request.getParameter("optionD");
                String correct = request.getParameter("correctOption").toUpperCase();
                String explanation = request.getParameter("explanation");
                int marks = Integer.parseInt(request.getParameter("marks"));

                String sql = "INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, marks) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, quizId);
                ps.setString(2, qText);
                ps.setString(3, optA);
                ps.setString(4, optB);
                ps.setString(5, optC);
                ps.setString(6, optD);
                ps.setString(7, correct);
                ps.setString(8, explanation);
                ps.setInt(9, marks);
                ps.executeUpdate();

            } else if ("delete".equalsIgnoreCase(action)) {
                int qId = Integer.parseInt(request.getParameter("questionId"));
                String sql = "DELETE FROM questions WHERE question_id = ?";
                ps = conn.prepareStatement(sql);
                ps.setInt(1, qId);
                ps.executeUpdate();
            }

            response.sendRedirect("admin-dashboard.jsp?status=Success");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin-dashboard.jsp?error=OperationFailed");
        } finally {
            DBConnection.close(ps, conn);
        }
    }
}
`
  },
  {
    name: 'web.xml',
    category: 'config',
    path: 'WebContent/WEB-INF/web.xml',
    description: 'Tomcat deployment descriptor mapping URLs to Servlets with session timeout settings.',
    code: `<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee 
         http://xmlns.jcp.org/xml/ns/javaee/web-app_4_0.xsd"
         version="4.0">

    <display-name>SmartQuiz Examination Portal</display-name>
    <description>Interactive Quiz Website with Live Countdown Timer for College Mini Project</description>

    <!-- Welcome File List -->
    <welcome-file-list>
        <welcome-file>index.html</welcome-file>
        <welcome-file>index.jsp</welcome-file>
    </welcome-file-list>

    <!-- Login Servlet -->
    <servlet>
        <servlet-name>LoginServlet</servlet-name>
        <servlet-class>com.smartquiz.controller.LoginServlet</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>LoginServlet</servlet-name>
        <url-pattern>/LoginServlet</url-pattern>
    </servlet-mapping>

    <!-- Register Servlet -->
    <servlet>
        <servlet-name>RegisterServlet</servlet-name>
        <servlet-class>com.smartquiz.controller.RegisterServlet</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>RegisterServlet</servlet-name>
        <url-pattern>/RegisterServlet</url-pattern>
    </servlet-mapping>

    <!-- Submit Quiz Servlet -->
    <servlet>
        <servlet-name>SubmitQuizServlet</servlet-name>
        <servlet-class>com.smartquiz.controller.SubmitQuizServlet</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>SubmitQuizServlet</servlet-name>
        <url-pattern>/SubmitQuizServlet</url-pattern>
    </servlet-mapping>

    <!-- Admin Question Management Servlet -->
    <servlet>
        <servlet-name>AdminQuestionServlet</servlet-name>
        <servlet-class>com.smartquiz.controller.AdminQuestionServlet</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>AdminQuestionServlet</servlet-name>
        <url-pattern>/AdminQuestionServlet</url-pattern>
    </servlet-mapping>

    <!-- Session Configuration: 30 minutes idle timeout -->
    <session-config>
        <session-timeout>30</session-timeout>
    </session-config>

</web-app>
`
  },
  {
    name: 'Tomcat_Setup_Guide.md',
    category: 'guide',
    path: 'docs/Tomcat_Setup_Guide.md',
    description: 'Beginner-friendly step-by-step instructions to configure Apache Tomcat and MySQL locally on Windows/Linux.',
    code: `# Apache Tomcat & MySQL Local Run Guide for 2-1 B.Tech Mini Project

## Prerequisites
1. **Java JDK 11 or JDK 17 / 21** installed (verify in terminal with \`java -version\`).
2. **Apache Tomcat 9 or 10** installed from [tomcat.apache.org](https://tomcat.apache.org/).
3. **MySQL Server 8.0** & **MySQL Workbench** installed.
4. **IDE**: Eclipse IDE for Enterprise Java and Web Developers, IntelliJ IDEA Ultimate, or VS Code.

---

## Step 1: Set Up MySQL Database
1. Open MySQL Workbench or MySQL Command Line Client:
   \`\`\`bash
   mysql -u root -p
   \`\`\`
2. Execute the provided script \`smartquiz.sql\`:
   \`\`\`sql
   source /path/to/smartquiz.sql;
   \`\`\`
3. Verify tables with:
   \`\`\`sql
   USE smartquiz;
   SHOW TABLES;
   \`\`\`

---

## Step 2: Add MySQL Connector/J Driver to Tomcat
1. Download \`mysql-connector-j-8.x.jar\` from MySQL official downloads.
2. Copy this \`.jar\` file into your Apache Tomcat \`lib/\` folder:
   - Example on Windows: \`C:\\Program Files\\Apache Software Foundation\\Tomcat 9.0\\lib\\\`
   - Example on Eclipse: Right click project -> Build Path -> Add External Archives -> select the jar.

---

## Step 3: Project Directory Structure
\`\`\`text
SmartQuiz/
├── WebContent/ (or src/main/webapp/)
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── timer.js
│   │   └── quiz.js
│   ├── index.html
│   ├── login.jsp
│   ├── register.jsp
│   ├── student-dashboard.jsp
│   ├── exam.jsp
│   ├── result.jsp
│   ├── admin-dashboard.jsp
│   └── WEB-INF/
│       ├── web.xml
│       └── lib/
│           ├── mysql-connector-j-8.0.33.jar
│           └── jstl-1.2.jar
└── src/
    └── com/smartquiz/
        ├── util/
        │   └── DBConnection.java
        └── controller/
            ├── LoginServlet.java
            ├── RegisterServlet.java
            ├── SubmitQuizServlet.java
            └── AdminQuestionServlet.java
\`\`\`

---

## Step 4: Run the Application
1. In Eclipse: Right-click project \`SmartQuiz\` -> **Run As** -> **Run on Server** -> Select Tomcat.
2. In Browser, visit:
   \`http://localhost:8080/SmartQuiz/\`
`
  },
  {
    name: 'Viva_Voce_QA.md',
    category: 'guide',
    path: 'docs/Viva_Voce_QA.md',
    description: '15 Top Viva Voce Questions & Answers frequently asked by external examiners in B.Tech lab examinations.',
    code: `# Top 15 Viva Voce Questions & Answers (2-1 Semester B.Tech)

### Q1: What is a Java Servlet and how does it differ from a standard Java program?
**Answer**: A Servlet is a server-side Java class that handles client HTTP requests and generates dynamic responses. Standard Java programs start via \`public static void main(String[] args)\`, whereas Servlets are managed entirely by a Servlet Container (like Apache Tomcat) via lifecycle methods (\`init()\`, \`service()\`, \`destroy()\`).

### Q2: What is the lifecycle of a Java Servlet?
**Answer**:
1. **Loading & Instantiation**: The container loads the class and creates an instance.
2. **Initialization**: \`init(ServletConfig config)\` is called exactly once.
3. **Request Handling**: \`service()\` delegates to \`doGet()\` or \`doPost()\` for every incoming HTTP request (multithreaded).
4. **Destruction**: \`destroy()\` is called once before the servlet is unloaded to release resources.

### Q3: Why did you use PreparedStatement instead of Statement in JDBC?
**Answer**:
1. **Security**: PreparedStatement uses parameter binding with \`?\` placeholders, completely preventing SQL Injection attacks.
2. **Performance**: PreparedStatement compiles the SQL query once on the database server; subsequent executions reuse the pre-compiled query execution plan.

### Q4: How does the Live Countdown Timer work and prevent cheating?
**Answer**:
The timer in JavaScript uses \`setInterval()\` to tick down every second. When navigating between questions via DOM or AJAX, the elapsed time is maintained in memory/session. Furthermore, when the timer reaches \`00:00\`, JavaScript invokes an automated form submit (\`form.submit()\`) to \`SubmitQuizServlet\`. The server also records the start timestamp in \`HttpSession\` to validate that the student did not exceed the allocated duration.

### Q5: What is the difference between doGet() and doPost()?
**Answer**:
- \`doGet()\`: Appends query parameters to the URL (visible in browser address bar), has payload length limitations (~2KB), is idempotent, and can be bookmarked.
- \`doPost()\`: Encapsulates data inside the HTTP request body (invisible in URL), handles large payloads, does not get cached, and is suitable for passwords and exam submissions.

### Q6: What is the role of the deployment descriptor (web.xml)?
**Answer**: \`web.xml\` is an XML configuration file located inside \`WEB-INF/\` that maps incoming URL patterns to corresponding Servlet classes, sets session timeout intervals, and configures welcome files.

### Q7: What are the ACID properties in MySQL?
**Answer**:
- **Atomicity**: Transactions execute completely or roll back completely ("all or nothing").
- **Consistency**: The database transitions from one valid state to another without violating schema constraints.
- **Isolation**: Concurrent transactions execute independently without interfering.
- **Durability**: Once committed, changes remain permanent even during hardware/power failure.

### Q8: What is the purpose of the student_answers table?
**Answer**: While \`quiz_results\` stores aggregate metrics (total score, percentage, pass/fail), \`student_answers\` stores the granular question-by-question choices chosen by the student. This allows the system to generate detailed answer reviews with explanations.

### Q9: Why is the WEB-INF directory protected in Tomcat?
**Answer**: The Java Servlet specification dictates that clients cannot directly browse or download files inside \`WEB-INF/\` (such as classes, libraries, or configuration files). Only server-side classes and \`RequestDispatcher.forward()\` can access them.

### Q10: How do you maintain session state across questions?
**Answer**: Using \`HttpSession\` in Java. Tomcat assigns a unique \`JSESSIONID\` cookie to the browser. As the student answers questions, choices can be stored in the session or submitted in bulk at the end.
`
  },
  {
    name: 'Netlify_Deployment_Guide.md',
    category: 'guide',
    path: 'docs/Netlify_Deployment_Guide.md',
    description: 'Step-by-step instructions for deploying SmartQuiz to Netlify via Git and downloading a ZIP archive.',
    code: `# Netlify Deployment & Git Export Guide for SmartQuiz

## Option A: Deploy to Netlify via GitHub (Recommended)

### Step 1: Initialize Git and Push to GitHub
Open your project folder in your local terminal (Command Prompt, PowerShell, or Git Bash) and execute:

\`\`\`bash
# 1. Initialize local Git repository
git init

# 2. Stage all project files
git add .

# 3. Create initial commit
git commit -m "Complete SmartQuiz college mini project with live timer"

# 4. Set main branch
git branch -M main

# 5. Link to your GitHub repository (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/smartquiz.git

# 6. Push code to GitHub
git push -u origin main
\`\`\`

---

### Step 2: Connect GitHub Repository to Netlify
1. Go to [https://app.netlify.com/](https://app.netlify.com/) and log in (or sign up free with GitHub).
2. Click **"Add new site"** -> **"Import an existing project"**.
3. Select **GitHub** as your Git provider and authorize Netlify.
4. Select your **smartquiz** repository from the list.
5. Netlify will automatically detect the settings from \`netlify.toml\`:
   - **Base directory**: (Leave blank)
   - **Build command**: \`npm run build\`
   - **Publish directory**: \`dist\`
6. Click **"Deploy smartquiz"**.
7. In ~30 seconds, your site will be live on a global HTTPS URL (e.g., \`https://smartquiz-portal.netlify.app\`).

---

## Option B: Deploy to Netlify via Drag-and-Drop (No Git Required)

1. On your computer, open the terminal in the \`smartquiz\` folder and run:
   \`\`\`bash
   npm install
   npm run build
   \`\`\`
2. This creates a production-ready \`dist/\` folder in your project root.
3. Open [https://app.netlify.com/drop](https://app.netlify.com/drop).
4. Drag and drop your **\`dist\`** folder onto the page.
5. Netlify immediately publishes your live website!

---

## How to Create and Extract a Project ZIP File

### Creating a Clean ZIP on Linux / Mac Terminal:
\`\`\`bash
# Exclude heavy node_modules and .git folders
zip -r smartquiz-project.zip . -x "node_modules/*" ".git/*" "dist/*"
\`\`\`

### Creating a Clean ZIP on Windows PowerShell:
\`\`\`powershell
# Compress all project files into a single zip
Compress-Archive -Path * -Exclude node_modules,dist,.git -DestinationPath smartquiz-project.zip
\`\`\`
`
  }
];

