/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { AuthModal } from './components/AuthModal';
import { StudentDashboard } from './components/StudentDashboard';
import { QuizExamView } from './components/QuizExamView';
import { ResultView } from './components/ResultView';
import { AdminDashboard } from './components/AdminDashboard';
import { ProjectHubModal } from './components/ProjectHubModal';
import { dbService } from './services/dbService';
import { Student, Admin, Quiz, Question, QuizResult, ViewState } from './types/quiz';

export default function App() {
  // Application View State
  const [currentView, setCurrentView] = useState<ViewState>('home');
  
  // Auth state
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [currentAdmin, setCurrentAdmin] = useState<Admin | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'student-login' | 'student-register' | 'admin-login'>('student-login');

  // Project Hub Modal
  const [isProjectHubOpen, setIsProjectHubOpen] = useState(false);

  // Active Quiz Examination State
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [activeResult, setActiveResult] = useState<QuizResult | null>(null);

  // Data sets from DB Service
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [results, setResults] = useState<QuizResult[]>([]);

  // Load initial data
  const refreshAllData = () => {
    setQuizzes(dbService.getQuizzes());
    setQuestions(dbService.getQuestions());
    setResults(dbService.getResults());
    setCurrentStudent(dbService.getCurrentStudent());
    setCurrentAdmin(dbService.getCurrentAdmin());
  };

  useEffect(() => {
    refreshAllData();

    // Default to Aarav Sharma if no user logged in to make testing instant
    const existingStudent = dbService.getCurrentStudent();
    if (!existingStudent) {
      const defaultStudent = dbService.getStudents()[0];
      if (defaultStudent) {
        dbService.setCurrentStudent(defaultStudent);
        setCurrentStudent(defaultStudent);
      }
    }
  }, []);

  // Auth Handlers
  const handleOpenAuth = (tab: 'student-login' | 'student-register' | 'admin-login' = 'student-login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const handleLoginSuccess = (type: 'student' | 'admin', user: Student | Admin) => {
    if (type === 'student') {
      setCurrentStudent(user as Student);
      setCurrentAdmin(null);
      setCurrentView('student-dashboard');
    } else {
      setCurrentAdmin(user as Admin);
      setCurrentStudent(null);
      setCurrentView('admin-dashboard');
    }
  };

  const handleLogout = () => {
    dbService.logout();
    setCurrentStudent(null);
    setCurrentAdmin(null);
    setCurrentView('home');
  };

  // Quiz Examination Handlers
  const handleStartQuiz = (quiz: Quiz) => {
    // Ensure student exists (fallback to default student if not logged in)
    let student = currentStudent;
    if (!student) {
      student = dbService.getStudents()[0];
      dbService.setCurrentStudent(student);
      setCurrentStudent(student);
    }

    setActiveQuiz(quiz);
    setCurrentView('quiz-exam');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmitExam = (
    userAnswers: Record<number, 'A' | 'B' | 'C' | 'D' | null>,
    timeSpentSeconds: number
  ) => {
    if (!activeQuiz) return;
    const student = currentStudent || dbService.getStudents()[0];

    const result = dbService.submitExam(
      activeQuiz.id,
      student,
      userAnswers,
      timeSpentSeconds
    );

    refreshAllData();
    setActiveResult(result);
    setCurrentView('quiz-result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleReviewResult = (result: QuizResult) => {
    setActiveResult(result);
    const matchedQuiz = dbService.getQuizById(result.quizId);
    if (matchedQuiz) {
      setActiveQuiz(matchedQuiz);
    }
    setCurrentView('quiz-result');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRetakeQuiz = () => {
    if (activeQuiz) {
      handleStartQuiz(activeQuiz);
    } else if (quizzes.length > 0) {
      handleStartQuiz(quizzes[0]);
    }
  };

  // Student specific results
  const studentResults = currentStudent ? dbService.getResultsByStudent(currentStudent.id) : [];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* Global Navigation Bar (Hidden during full examination view to eliminate distractions) */}
      {currentView !== 'quiz-exam' && (
        <Navbar
          currentView={currentView}
          setCurrentView={setCurrentView}
          currentStudent={currentStudent}
          currentAdmin={currentAdmin}
          onOpenAuth={handleOpenAuth}
          onOpenProjectHub={() => setIsProjectHubOpen(true)}
          onLogout={handleLogout}
        />
      )}

      {/* Main Views Container */}
      <div className="flex-1">
        
        {/* 1. LANDING PAGE */}
        {currentView === 'home' && (
          <LandingPage
            quizzes={quizzes}
            currentStudent={currentStudent}
            onSelectQuiz={handleStartQuiz}
            onOpenAuth={handleOpenAuth}
            onOpenProjectHub={() => setIsProjectHubOpen(true)}
          />
        )}

        {/* 2. STUDENT DASHBOARD */}
        {currentView === 'student-dashboard' && currentStudent && (
          <StudentDashboard
            student={currentStudent}
            quizzes={quizzes}
            results={studentResults}
            onStartQuiz={handleStartQuiz}
            onReviewResult={handleReviewResult}
          />
        )}

        {/* 3. QUIZ EXAMINATION PAGE (THE CORE FEATURE) */}
        {currentView === 'quiz-exam' && activeQuiz && (
          <QuizExamView
            quiz={activeQuiz}
            questions={dbService.getQuestionsByQuizId(activeQuiz.id)}
            student={currentStudent || dbService.getStudents()[0]}
            onSubmitExam={handleSubmitExam}
            onExitWithoutSaving={() => setCurrentView('student-dashboard')}
          />
        )}

        {/* 4. RESULT PAGE WITH CIRCULAR SCORE CHART & DETAILED REVIEW */}
        {currentView === 'quiz-result' && activeResult && (
          <ResultView
            result={activeResult}
            quiz={activeQuiz || dbService.getQuizById(activeResult.quizId)}
            questions={dbService.getQuestionsByQuizId(activeResult.quizId)}
            onRetakeQuiz={handleRetakeQuiz}
            onGoToDashboard={() => setCurrentView('student-dashboard')}
          />
        )}

        {/* 5. ADMIN DASHBOARD */}
        {currentView === 'admin-dashboard' && currentAdmin && (
          <AdminDashboard
            admin={currentAdmin}
            quizzes={quizzes}
            questions={questions}
            results={results}
            onRefreshData={refreshAllData}
            onLogout={handleLogout}
          />
        )}

      </div>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        defaultTab={authModalTab}
        onLoginSuccess={handleLoginSuccess}
      />

      <ProjectHubModal
        isOpen={isProjectHubOpen}
        onClose={() => setIsProjectHubOpen(false)}
      />

    </div>
  );
}
