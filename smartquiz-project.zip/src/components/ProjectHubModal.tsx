import React, { useState } from 'react';
import { 
  X, 
  Code2, 
  Copy, 
  Check, 
  Download, 
  Database, 
  Server, 
  FileText, 
  HelpCircle, 
  FolderTree, 
  Layers, 
  ExternalLink,
  BookOpen,
  Terminal,
  CheckCircle2,
  Globe
} from 'lucide-react';
import { JAVA_PROJECT_FILES, JavaFile } from '../data/javaProjectCode';

interface ProjectHubModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProjectHubModal: React.FC<ProjectHubModalProps> = ({ isOpen, onClose }) => {
  const [selectedFile, setSelectedFile] = useState<JavaFile>(JAVA_PROJECT_FILES[0]);
  const [activeTab, setActiveTab] = useState<'code' | 'architecture' | 'viva' | 'tomcat' | 'netlify'>('code');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = selectedFile.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/70 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-6xl h-[92vh] bg-slate-900 text-slate-100 rounded-3xl shadow-2xl border border-slate-800 flex flex-col overflow-hidden">
        
        {/* Top Header */}
        <div className="bg-slate-950/80 px-6 py-4 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>College Mini Project Hub & Java Source Center</span>
                <span className="text-[10px] font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full">
                  B.Tech 2-1 Semester
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Complete Java Servlets, JDBC PreparedStatement, MySQL DDL/DML, and Viva Voce Guide.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="/smartquiz-project.zip"
              download="smartquiz-project.zip"
              className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors"
              title="Download complete codebase ZIP"
            >
              <Download className="w-4 h-4" />
              <span>Download Project (.ZIP)</span>
            </a>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="bg-slate-900/90 px-6 py-2.5 border-b border-slate-800 flex items-center gap-2 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('code')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'code' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Code2 className="w-4 h-4" />
            Backend Source Files ({JAVA_PROJECT_FILES.length})
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'architecture' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            System Architecture & ER Diagram
          </button>
          <button
            onClick={() => setActiveTab('viva')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'viva' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            15 Top Viva Voce Q&A
          </button>
          <button
            onClick={() => setActiveTab('tomcat')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'tomcat' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Server className="w-4 h-4" />
            Apache Tomcat Setup Guide
          </button>
          <button
            onClick={() => setActiveTab('netlify')}
            className={`px-3.5 py-1.5 rounded-lg font-semibold transition-colors flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'netlify' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Globe className="w-4 h-4 text-cyan-400" />
            Netlify & Git Deploy Guide
          </button>
        </div>

        {/* Tab 1: Code Browser */}
        {activeTab === 'code' && (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            
            {/* Left File Tree Sidebar */}
            <aside className="w-full md:w-64 bg-slate-950/60 border-r border-slate-800 p-4 overflow-y-auto space-y-4 shrink-0 text-xs">
              <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                Project Files
              </div>
              <div className="space-y-1">
                {JAVA_PROJECT_FILES.map(file => {
                  const isSelected = selectedFile.name === file.name;
                  return (
                    <button
                      key={file.name}
                      onClick={() => { setSelectedFile(file); setCopied(false); }}
                      className={`w-full text-left px-3 py-2 rounded-xl transition-all flex items-center gap-2.5 font-mono ${
                        isSelected 
                          ? 'bg-indigo-600 text-white font-semibold shadow-xs' 
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
                      }`}
                    >
                      {file.category === 'java' && <span className="text-[10px] text-amber-400 font-bold">☕</span>}
                      {file.category === 'sql' && <span className="text-[10px] text-cyan-400 font-bold">🗄️</span>}
                      {file.category === 'config' && <span className="text-[10px] text-purple-400 font-bold">⚙️</span>}
                      {file.category === 'guide' && <span className="text-[10px] text-emerald-400 font-bold">📄</span>}
                      <span className="truncate">{file.name}</span>
                    </button>
                  );
                })}
              </div>

              <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-500 space-y-1.5 font-sans">
                <p className="font-semibold text-slate-400">Folder Path:</p>
                <code className="text-[10px] text-indigo-300 block bg-slate-900 p-1.5 rounded font-mono truncate">
                  {selectedFile.path}
                </code>
              </div>
            </aside>

            {/* Right Code Display */}
            <main className="flex-1 flex flex-col bg-slate-900 overflow-hidden">
              
              {/* File Info Bar */}
              <div className="px-6 py-3 bg-slate-950/40 border-b border-slate-800 flex items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-mono font-bold text-white">{selectedFile.name}</span>
                  <p className="text-[11px] text-slate-400 line-clamp-1">{selectedFile.description}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyCode}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg font-medium transition-colors flex items-center gap-1.5"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy Code'}</span>
                  </button>

                  <button
                    onClick={handleDownloadFile}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs rounded-lg font-medium transition-colors flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download File</span>
                  </button>
                </div>
              </div>

              {/* Code Pre Block */}
              <div className="flex-1 p-6 overflow-auto font-mono text-xs leading-relaxed bg-slate-950/80 text-indigo-100">
                <pre>{selectedFile.code}</pre>
              </div>

            </main>

          </div>
        )}

        {/* Tab 2: Architecture & ER Diagram */}
        {activeTab === 'architecture' && (
          <div className="flex-1 p-6 sm:p-8 overflow-y-auto space-y-6 text-sm">
            
            <div className="max-w-4xl mx-auto space-y-8">
              
              <div>
                <h3 className="text-lg font-bold text-white mb-2">
                  System Architecture (3-Tier Web Architecture)
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  How client browsers interact with Apache Tomcat and the MySQL database in this mini project:
                </p>
              </div>

              {/* Architecture ASCII / Visual Flow */}
              <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 font-mono text-xs text-indigo-200 leading-loose overflow-x-auto">
{`+-----------------------------------------------------------------------------------+
|                           PRESENTATION LAYER (Client)                             |
|  - HTML5 & CSS3 (Modern Responsive UI)                                             |
|  - JavaScript ES6+ (Live MM:SS Countdown Timer, Question Navigation, Auto-Submit)   |
+-----------------------------------------------------------------------------------+
                                         │
                                         ▼ HTTP POST / GET (JSON & Form Payloads)
+-----------------------------------------------------------------------------------+
|                        APPLICATION LAYER (Apache Tomcat 9/10)                     |
|                                                                                   |
|  - web.xml (Deployment Descriptor & URL Mapping)                                  |
|  - LoginServlet.java (Student & Admin Authentication, HttpSession JSESSIONID)      |
|  - RegisterServlet.java (New Student Account Creation)                            |
|  - QuizServlet.java (Dynamic Question Retrieval)                                  |
|  - SubmitQuizServlet.java (Score Calculation, Transaction Handling)                |
|  - AdminQuestionServlet.java (Faculty CRUD Operations)                            |
|  - DBConnection.java (JDBC Singleton Connection Manager)                          |
+-----------------------------------------------------------------------------------+
                                         │
                                         ▼ JDBC PreparedStatement (TCP Port 3306)
+-----------------------------------------------------------------------------------+
|                          DATABASE LAYER (MySQL 8.0)                               |
|                                                                                   |
|  - Database: smartquiz                                                            |
|  - Tables:                                                                        |
|      1. students        (student_id PK, roll_no UNIQUE, email, password, branch)   |
|      2. admins          (admin_id PK, username, email, password, role)            |
|      3. quizzes         (quiz_id PK, title, duration_minutes, passing_percentage) |
|      4. questions       (question_id PK, quiz_id FK, options A-D, correct_option)  |
|      5. quiz_results    (result_id PK, student_id FK, score, percentage, passed)   |
|      6. student_answers (answer_id PK, result_id FK, question_id FK, choice)      |
+-----------------------------------------------------------------------------------+`}
              </div>

              {/* Relational ER Schema Explanation */}
              <div className="bg-slate-800/50 p-5 rounded-2xl border border-slate-800 space-y-3 text-xs text-slate-300">
                <h4 className="font-bold text-white text-sm">Key Relationships in MySQL Database:</h4>
                <p>• <strong>students (1) — to — (M) quiz_results:</strong> One student can attempt multiple quizzes over time.</p>
                <p>• <strong>quizzes (1) — to — (M) questions:</strong> Each quiz contains multiple multiple-choice questions with CASCADE DELETE enabled.</p>
                <p>• <strong>quiz_results (1) — to — (M) student_answers:</strong> Each submission records the granular choice selected for each individual question to enable the pedagogical answer review page.</p>
              </div>

            </div>

          </div>
        )}

        {/* Tab 3: Viva Voce Q&A */}
        {activeTab === 'viva' && (
          <div className="flex-1 p-6 sm:p-8 overflow-y-auto space-y-6 text-sm">
            <div className="max-w-4xl mx-auto space-y-6">
              
              <div>
                <h3 className="text-lg font-bold text-white mb-1">
                  15 High-Yield Viva Voce Questions & Answers
                </h3>
                <p className="text-xs text-slate-400">
                  Carefully compiled to help you confidently answer questions from internal and external examiners during lab viva!
                </p>
              </div>

              <div className="space-y-4">
                {JAVA_PROJECT_FILES.find(f => f.name === 'Viva_Voce_QA.md')?.code.split('### ').slice(1).map((item, idx) => {
                  const parts = item.split('**Answer**:');
                  const question = parts[0]?.trim();
                  const answer = parts[1]?.trim();

                  return (
                    <div key={idx} className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2">
                      <div className="font-bold text-indigo-300 text-sm flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-indigo-600/30 text-indigo-400 flex items-center justify-center text-xs shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span>{question}</span>
                      </div>
                      <div className="text-xs text-slate-300 leading-relaxed pl-7">
                        {answer}
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>
          </div>
        )}

        {/* Tab 4: Apache Tomcat Setup Guide */}
        {activeTab === 'tomcat' && (
          <div className="flex-1 p-6 sm:p-8 overflow-y-auto text-sm">
            <div className="max-w-4xl mx-auto space-y-6">
              
              <div>
                <h3 className="text-lg font-bold text-white mb-1">
                  How to Run SmartQuiz on Apache Tomcat Locally
                </h3>
                <p className="text-xs text-slate-400">
                  Beginner-friendly step-by-step instructions for Eclipse, IntelliJ, or standalone Tomcat.
                </p>
              </div>

              <div className="space-y-4">
                <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2 text-xs">
                  <span className="font-bold text-indigo-400 text-sm">Step 1: Install MySQL and Create the Database</span>
                  <p className="text-slate-300">
                    Open MySQL Workbench or Command Line and execute <code className="text-amber-300 font-mono">smartquiz.sql</code> from Tab 1. This creates the 6 tables and inserts sample quiz questions.
                  </p>
                </div>

                <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2 text-xs">
                  <span className="font-bold text-indigo-400 text-sm">Step 2: Add MySQL Connector JAR</span>
                  <p className="text-slate-300">
                    Download <code className="text-amber-300 font-mono">mysql-connector-j-8.0.33.jar</code> and place it inside your Tomcat <code className="text-amber-300 font-mono">lib/</code> folder or your project's <code className="text-amber-300 font-mono">WebContent/WEB-INF/lib/</code>.
                  </p>
                </div>

                <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2 text-xs">
                  <span className="font-bold text-indigo-400 text-sm">Step 3: Deploy and Run</span>
                  <p className="text-slate-300">
                    In Eclipse, right click your project &gt; <strong>Run As</strong> &gt; <strong>Run on Server</strong> &gt; Select Apache Tomcat 9/10. Open <code className="text-indigo-300 font-mono">http://localhost:8080/SmartQuiz/</code> in Chrome.
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Tab 5: Netlify & Git Deployment Guide */}
        {activeTab === 'netlify' && (
          <div className="flex-1 p-6 sm:p-8 overflow-y-auto text-sm space-y-6">
            <div className="max-w-4xl mx-auto space-y-6">
              
              <div>
                <h3 className="text-lg font-bold text-white mb-1 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-cyan-400" />
                  How to Deploy SmartQuiz to Netlify (Live on Web)
                </h3>
                <p className="text-xs text-slate-400">
                  Step-by-step instructions for deploying your project to Netlify via GitHub or manual drag-and-drop.
                </p>
              </div>

              {/* Method 1: Git + Netlify */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center justify-center">1</span>
                  <h4 className="font-bold text-white text-sm">Deploy via GitHub &amp; Netlify CI/CD (Recommended)</h4>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Run these standard Git commands in your terminal to push your SmartQuiz project to GitHub:
                </p>

                <div className="bg-slate-900 text-cyan-300 p-4 rounded-xl font-mono text-xs overflow-x-auto border border-slate-800 space-y-1">
                  <div>git init</div>
                  <div>git add .</div>
                  <div>git commit -m &quot;Initial commit: SmartQuiz college mini project&quot;</div>
                  <div>git branch -M main</div>
                  <div>git remote add origin https://github.com/YOUR_USERNAME/smartquiz.git</div>
                  <div>git push -u origin main</div>
                </div>

                <div className="pt-2 text-xs text-slate-300 space-y-1.5">
                  <p>1. Open <a href="https://app.netlify.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline font-semibold">Netlify.com</a> and sign in with GitHub.</p>
                  <p>2. Click <strong>&quot;Add new site&quot;</strong> &gt; <strong>&quot;Import an existing project&quot;</strong> &gt; select your <strong>smartquiz</strong> repo.</p>
                  <p>3. Netlify automatically reads your pre-configured <code className="text-amber-300 font-mono">netlify.toml</code>:</p>
                  <ul className="list-disc pl-5 text-[11px] text-slate-400 space-y-0.5">
                    <li>Build command: <code className="text-slate-200">npm run build</code></li>
                    <li>Publish directory: <code className="text-slate-200">dist</code></li>
                    <li>SPA Redirects: <code className="text-slate-200">/* -&gt; /index.html 200</code></li>
                  </ul>
                  <p>4. Click <strong>&quot;Deploy Site&quot;</strong> — Netlify will build and host your website with a free global HTTPS URL in seconds!</p>
                </div>
              </div>

              {/* Method 2: Drag and drop */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-purple-600 text-white font-bold text-xs flex items-center justify-center">2</span>
                  <h4 className="font-bold text-white text-sm">Deploy via Netlify Drag &amp; Drop (No Git Required)</h4>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  If you prefer deploying without Git:
                </p>

                <ol className="list-decimal pl-5 text-xs text-slate-300 space-y-1.5">
                  <li>In your project terminal, run: <code className="text-amber-300 font-mono">npm run build</code></li>
                  <li>This compiles all HTML, CSS, and JavaScript into a production folder named <code className="text-amber-300 font-mono">dist/</code></li>
                  <li>Visit <a href="https://app.netlify.com/drop" target="_blank" rel="noreferrer" className="text-cyan-400 underline font-semibold">app.netlify.com/drop</a></li>
                  <li>Drag and drop the <code className="text-amber-300 font-mono">dist/</code> folder right into the browser box to publish instantly!</li>
                </ol>
              </div>

              {/* ZIP Archive Guide */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">3</span>
                  <h4 className="font-bold text-white text-sm">How to Create &amp; Extract the Project ZIP File</h4>
                </div>

                <div className="space-y-2 text-xs text-slate-300">
                  <p>To pack the complete project without heavy <code className="font-mono text-slate-400">node_modules</code>:</p>
                  <div className="bg-slate-900 text-emerald-300 p-3 rounded-xl font-mono text-xs overflow-x-auto border border-slate-800">
                    zip -r smartquiz-project.zip . -x &quot;node_modules/*&quot; &quot;.git/*&quot; &quot;dist/*&quot;
                  </div>
                  <p className="text-[11px] text-slate-400">
                    To run after extracting: uncompress the zip, run <code className="text-slate-200 font-mono">npm install</code>, then <code className="text-slate-200 font-mono">npm run dev</code>.
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
