import React, { useState } from 'react';
import { X, User, Lock, Mail, Hash, BookOpen, ShieldCheck, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { Student, Admin } from '../types/quiz';
import { dbService } from '../services/dbService';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'student-login' | 'student-register' | 'admin-login';
  onLoginSuccess: (type: 'student' | 'admin', user: Student | Admin) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'student-login',
  onLoginSuccess
}) => {
  const [tab, setTab] = useState<'student-login' | 'student-register' | 'admin-login'>(defaultTab);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Student Login Fields
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Student Register Fields
  const [regRollNo, setRegRollNo] = useState('');
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regBranch, setRegBranch] = useState('Computer Science & Engineering');
  const [regYearSem, setRegYearSem] = useState('2-1 Sem');

  // Admin Login Fields
  const [adminIdentifier, setAdminIdentifier] = useState('admin@smartquiz.edu');
  const [adminPassword, setAdminPassword] = useState('admin123');

  if (!isOpen) return null;

  const handleStudentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!loginIdentifier.trim() || !loginPassword.trim()) {
      setError('Please provide your Roll Number / Email and Password.');
      return;
    }

    const res = dbService.loginStudent(loginIdentifier, loginPassword);
    if (res.success && res.student) {
      onLoginSuccess('student', res.student);
      onClose();
    } else {
      setError(res.error || 'Authentication failed');
    }
  };

  const handleStudentRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!regRollNo.trim() || !regFullName.trim() || !regEmail.trim() || !regPassword.trim()) {
      setError('All fields are required for student registration.');
      return;
    }

    if (regPassword.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }

    const res = dbService.registerStudent({
      rollNo: regRollNo.trim().toUpperCase(),
      name: regFullName.trim(),
      email: regEmail.trim(),
      password: regPassword,
      branch: regBranch,
      year: regYearSem,
    });

    if (res.success && res.student) {
      setSuccessMsg('Registration successful! Redirecting to login...');
      setTimeout(() => {
        setLoginIdentifier(res.student!.rollNo);
        setLoginPassword(regPassword);
        setTab('student-login');
        setSuccessMsg(null);
      }, 1000);
    } else {
      setError(res.error || 'Registration failed');
    }
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const res = dbService.loginAdmin(adminIdentifier, adminPassword);
    if (res.success && res.admin) {
      onLoginSuccess('admin', res.admin);
      onClose();
    } else {
      setError(res.error || 'Invalid admin credentials');
    }
  };

  const quickFillStudent = (roll: string, pass: string) => {
    setLoginIdentifier(roll);
    setLoginPassword(pass);
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden">
        
        {/* Header Tabs */}
        <div className="bg-slate-50 border-b border-slate-100 p-2 flex items-center justify-between">
          <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-xl w-full mr-2">
            <button
              onClick={() => { setTab('student-login'); setError(null); }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                tab === 'student-login'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Student Login
            </button>
            <button
              onClick={() => { setTab('student-register'); setError(null); }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                tab === 'student-register'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Register
            </button>
            <button
              onClick={() => { setTab('admin-login'); setError(null); }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                tab === 'admin-login'
                  ? 'bg-white text-purple-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Admin Portal
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          
          {/* Notification alerts */}
          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-700 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* TAB 1: STUDENT LOGIN */}
          {tab === 'student-login' && (
            <div>
              <div className="mb-5">
                <h3 className="text-xl font-bold text-slate-900">Student Sign In</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Access examination hall and personal test scores.
                </p>
              </div>

              <form onSubmit={handleStudentLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Roll Number or Email
                  </label>
                  <div className="relative">
                    <Hash className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      placeholder="e.g. 21A91A0501 or aarav@college.edu"
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all font-mono"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="password"
                      placeholder="Enter student password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-indigo-200 transition-colors flex items-center justify-center gap-2 mt-2"
                >
                  Enter Examination Dashboard
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {/* Demo quick fill buttons for evaluator */}
              <div className="mt-6 pt-4 border-t border-slate-100">
                <span className="text-[11px] font-semibold text-slate-400 block mb-2">
                  1-Click Demo Students:
                </span>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => quickFillStudent('21A91A0501', 'password123')}
                    className="text-xs px-2.5 py-1.5 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 border border-slate-200 rounded-lg text-slate-700 transition-colors font-mono"
                  >
                    21A91A0501 (Aarav)
                  </button>
                  <button
                    type="button"
                    onClick={() => quickFillStudent('21A91A0542', 'password123')}
                    className="text-xs px-2.5 py-1.5 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 border border-slate-200 rounded-lg text-slate-700 transition-colors font-mono"
                  >
                    21A91A0542 (Priya)
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: STUDENT REGISTRATION */}
          {tab === 'student-register' && (
            <div>
              <div className="mb-4">
                <h3 className="text-xl font-bold text-slate-900">Student Registration</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Enrolls candidate in the MySQL <code className="font-mono text-purple-700">students</code> table.
                </p>
              </div>

              <form onSubmit={handleStudentRegister} className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Roll Number *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 21A91A0599"
                      value={regRollNo}
                      onChange={(e) => setRegRollNo(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:border-indigo-600 font-mono uppercase"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Rohan Verma"
                      value={regFullName}
                      onChange={(e) => setRegFullName(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:border-indigo-600"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    placeholder="student@college.edu"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:border-indigo-600"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Branch / Dept
                    </label>
                    <select
                      value={regBranch}
                      onChange={(e) => setRegBranch(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:border-indigo-600"
                    >
                      <option value="Computer Science & Engineering">CSE</option>
                      <option value="Information Technology">IT</option>
                      <option value="AI & Data Science">AI & DS</option>
                      <option value="Electronics & Comm. Eng">ECE</option>
                      <option value="Mechanical Engineering">MECH</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Year / Semester
                    </label>
                    <select
                      value={regYearSem}
                      onChange={(e) => setRegYearSem(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:border-indigo-600"
                    >
                      <option value="2-1 Sem">2-1 Sem</option>
                      <option value="2-2 Sem">2-2 Sem</option>
                      <option value="3-1 Sem">3-1 Sem</option>
                      <option value="3-2 Sem">3-2 Sem</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Create Password *
                  </label>
                  <input
                    type="password"
                    placeholder="Minimum 6 characters"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:border-indigo-600"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-md shadow-indigo-200 transition-colors mt-2"
                >
                  Complete Registration & Enroll
                </button>
              </form>
            </div>
          )}

          {/* TAB 3: ADMIN LOGIN */}
          {tab === 'admin-login' && (
            <div>
              <div className="mb-5">
                <div className="flex items-center gap-2 mb-1">
                  <ShieldCheck className="w-5 h-5 text-purple-600" />
                  <h3 className="text-xl font-bold text-slate-900">Exam Controller Portal</h3>
                </div>
                <p className="text-xs text-slate-500">
                  Manage test question banks, inspect MySQL records, and evaluate score tallies.
                </p>
              </div>

              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Admin Username or Email
                  </label>
                  <input
                    type="text"
                    value={adminIdentifier}
                    onChange={(e) => setAdminIdentifier(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-600 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Master Password
                  </label>
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-600"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold text-sm rounded-xl shadow-md shadow-purple-200 transition-colors flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Sign In to Admin Dashboard
                </button>
              </form>

              <div className="mt-6 pt-4 border-t border-slate-100 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setAdminIdentifier('admin@smartquiz.edu');
                    setAdminPassword('admin123');
                    setError(null);
                  }}
                  className="text-xs text-purple-700 hover:text-purple-900 font-medium"
                >
                  Fill Default Admin Credentials (admin@smartquiz.edu / admin123)
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
