import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Search, 
  Layers, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  BookOpen, 
  Database, 
  ShieldCheck, 
  RotateCcw,
  AlertCircle,
  FileQuestion,
  Users
} from 'lucide-react';
import { Admin, Quiz, Question, QuizResult } from '../types/quiz';
import { dbService } from '../services/dbService';

interface AdminDashboardProps {
  admin: Admin;
  quizzes: Quiz[];
  questions: Question[];
  results: QuizResult[];
  onRefreshData: () => void;
  onLogout: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  admin,
  quizzes,
  questions,
  results,
  onRefreshData,
  onLogout
}) => {
  const [activeTab, setActiveTab] = useState<'questions' | 'quizzes' | 'results' | 'db-inspector'>('questions');
  const [selectedQuizId, setSelectedQuizId] = useState<number>(quizzes[0]?.id || 1);
  const [searchStudentQuery, setSearchStudentQuery] = useState('');

  // Add / Edit Question Modal State
  const [isQuestionModalOpen, setIsQuestionModalOpen] = useState(false);
  const [editingQuestionId, setEditingQuestionId] = useState<number | null>(null);
  const [qQuizId, setQQuizId] = useState<number>(selectedQuizId);
  const [qText, setQText] = useState('');
  const [qCodeSnippet, setQCodeSnippet] = useState('');
  const [qOptA, setQOptA] = useState('');
  const [qOptB, setQOptB] = useState('');
  const [qOptC, setQOptC] = useState('');
  const [qOptD, setQOptD] = useState('');
  const [qCorrect, setQCorrect] = useState<'A' | 'B' | 'C' | 'D'>('A');
  const [qExplanation, setQExplanation] = useState('');
  const [qMarks, setQMarks] = useState(1);

  // Create Quiz Modal State
  const [isQuizModalOpen, setIsQuizModalOpen] = useState(false);
  const [newQuizTitle, setNewQuizTitle] = useState('');
  const [newQuizCategory, setNewQuizCategory] = useState('Computer Science');
  const [newQuizDesc, setNewQuizDesc] = useState('');
  const [newQuizDuration, setNewQuizDuration] = useState(10);
  const [newQuizPass, setNewQuizPass] = useState(50);

  // Filtered questions
  const displayedQuestions = questions.filter(q => q.quizId === selectedQuizId);

  // Filtered results
  const displayedResults = results.filter(r => 
    r.studentName.toLowerCase().includes(searchStudentQuery.toLowerCase()) ||
    r.studentRollNo.toLowerCase().includes(searchStudentQuery.toLowerCase()) ||
    r.quizTitle.toLowerCase().includes(searchStudentQuery.toLowerCase())
  );

  const handleOpenAddQuestion = () => {
    setEditingQuestionId(null);
    setQQuizId(selectedQuizId);
    setQText('');
    setQCodeSnippet('');
    setQOptA('');
    setQOptB('');
    setQOptC('');
    setQOptD('');
    setQCorrect('A');
    setQExplanation('');
    setQMarks(1);
    setIsQuestionModalOpen(true);
  };

  const handleOpenEditQuestion = (q: Question) => {
    setEditingQuestionId(q.id);
    setQQuizId(q.quizId);
    setQText(q.questionText);
    setQCodeSnippet(q.codeSnippet || '');
    setQOptA(q.options.A);
    setQOptB(q.options.B);
    setQOptC(q.options.C);
    setQOptD(q.options.D);
    setQCorrect(q.correctOption);
    setQExplanation(q.explanation);
    setQMarks(q.marks);
    setIsQuestionModalOpen(true);
  };

  const handleSaveQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!qText.trim() || !qOptA.trim() || !qOptB.trim() || !qOptC.trim() || !qOptD.trim()) {
      alert('Please fill out the question text and all four options.');
      return;
    }

    if (editingQuestionId) {
      dbService.updateQuestion(editingQuestionId, {
        quizId: qQuizId,
        questionText: qText,
        codeSnippet: qCodeSnippet.trim() ? qCodeSnippet : undefined,
        options: { A: qOptA, B: qOptB, C: qOptC, D: qOptD },
        correctOption: qCorrect,
        explanation: qExplanation,
        marks: qMarks
      });
    } else {
      dbService.addQuestion({
        quizId: qQuizId,
        questionText: qText,
        codeSnippet: qCodeSnippet.trim() ? qCodeSnippet : undefined,
        options: { A: qOptA, B: qOptB, C: qOptC, D: qOptD },
        correctOption: qCorrect,
        explanation: qExplanation,
        marks: qMarks
      });
    }

    setIsQuestionModalOpen(false);
    onRefreshData();
  };

  const handleDeleteQuestion = (id: number) => {
    if (confirm('Are you sure you want to permanently delete this question from MySQL?')) {
      dbService.deleteQuestion(id);
      onRefreshData();
    }
  };

  const handleCreateQuiz = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuizTitle.trim()) return;

    dbService.createQuiz({
      title: newQuizTitle,
      category: newQuizCategory,
      description: newQuizDesc,
      durationMinutes: newQuizDuration,
      totalMarks: 10,
      passingPercentage: newQuizPass,
      iconName: 'BookOpen',
      difficulty: 'Intermediate'
    });

    setIsQuizModalOpen(false);
    setNewQuizTitle('');
    setNewQuizDesc('');
    onRefreshData();
  };

  const handleResetDatabase = () => {
    if (confirm('Reset simulated MySQL database back to default initial seed questions and student records?')) {
      dbService.resetToDefaults();
      onRefreshData();
      alert('Database restored to original state!');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in">
      
      {/* 1. ADMIN HEADER BANNER */}
      <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-purple-200">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                Exam Controller Dashboard
              </h1>
              <span className="text-[10px] font-semibold bg-purple-500/30 border border-purple-400/40 text-purple-200 px-2 py-0.5 rounded-full uppercase">
                Admin
              </span>
            </div>
            <p className="text-xs text-purple-200/90 mt-1">
              Logged in as {admin.name} ({admin.email}) · MySQL Schema Authority
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <div className="bg-white/10 px-3 py-2 rounded-xl border border-white/10">
            <span className="text-purple-300 block text-[10px] uppercase font-sans font-medium">Quizzes</span>
            <span className="font-bold text-base">{quizzes.length}</span>
          </div>
          <div className="bg-white/10 px-3 py-2 rounded-xl border border-white/10">
            <span className="text-purple-300 block text-[10px] uppercase font-sans font-medium">Questions</span>
            <span className="font-bold text-base">{questions.length}</span>
          </div>
          <div className="bg-white/10 px-3 py-2 rounded-xl border border-white/10">
            <span className="text-purple-300 block text-[10px] uppercase font-sans font-medium">Submissions</span>
            <span className="font-bold text-base">{results.length}</span>
          </div>
        </div>
      </div>

      {/* 2. ADMIN TABS BAR */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-4 gap-4 flex-wrap">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
          <button
            onClick={() => setActiveTab('questions')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'questions' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileQuestion className="w-4 h-4" />
            Question Bank ({questions.length})
          </button>
          <button
            onClick={() => setActiveTab('quizzes')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'quizzes' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            Manage Quizzes ({quizzes.length})
          </button>
          <button
            onClick={() => setActiveTab('results')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'results' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            Student Results ({results.length})
          </button>
          <button
            onClick={() => setActiveTab('db-inspector')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'db-inspector' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4" />
            MySQL Inspector
          </button>
        </div>

        <button
          onClick={handleResetDatabase}
          className="text-xs px-3 py-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg border border-slate-200 transition-colors flex items-center gap-1.5"
          title="Reset database to seed data"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset DB to Seeds
        </button>
      </div>

      {/* 3. TAB 1: QUESTION BANK CRUD */}
      {activeTab === 'questions' && (
        <div className="space-y-6">
          
          {/* Filter Bar & Add Button */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center gap-3">
              <label className="text-xs font-semibold text-slate-600">Select Quiz:</label>
              <select
                value={selectedQuizId}
                onChange={(e) => setSelectedQuizId(Number(e.target.value))}
                className="text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:border-indigo-600"
              >
                {quizzes.map(q => (
                  <option key={q.id} value={q.id}>
                    {q.title} ({q.category})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleOpenAddQuestion}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Add New Question
            </button>
          </div>

          {/* Questions List */}
          <div className="space-y-4">
            {displayedQuestions.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 text-slate-400 text-xs">
                No questions exist for this quiz yet. Click "Add New Question" above to insert.
              </div>
            ) : (
              displayedQuestions.map((q, idx) => (
                <div 
                  key={q.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-colors space-y-3"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-lg bg-indigo-50 text-indigo-700 font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <div>
                        <h4 className="text-sm font-semibold text-slate-900 leading-snug">
                          {q.questionText}
                        </h4>
                        {q.codeSnippet && (
                          <div className="mt-2 bg-slate-900 text-slate-100 rounded-xl p-3 font-mono text-xs max-w-xl overflow-x-auto">
                            <pre>{q.codeSnippet}</pre>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleOpenEditQuestion(q)}
                        className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="Edit question"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteQuestion(q.id)}
                        className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete question"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* 4 Options Preview */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1 pl-9">
                    {(['A', 'B', 'C', 'D'] as const).map(optKey => (
                      <div 
                        key={optKey} 
                        className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                          optKey === q.correctOption
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-semibold'
                            : 'bg-slate-50/70 border-slate-200 text-slate-600'
                        }`}
                      >
                        <span className={`w-4 h-4 rounded-full text-[10px] font-bold flex items-center justify-center ${
                          optKey === q.correctOption ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                        }`}>
                          {optKey}
                        </span>
                        <span className="truncate">{q.options[optKey]}</span>
                        {optKey === q.correctOption && (
                          <span className="text-[10px] text-emerald-700 ml-auto font-bold font-sans">
                            (KEY)
                          </span>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="pl-9 pt-1 text-[11px] text-slate-500">
                    <span className="font-semibold text-slate-700">Explanation:</span> {q.explanation}
                  </div>
                </div>
              ))
            )}
          </div>

        </div>
      )}

      {/* 4. TAB 2: MANAGE QUIZZES */}
      {activeTab === 'quizzes' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">Configured Departmental Examinations</h3>
            <button
              onClick={() => setIsQuizModalOpen(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Create New Quiz
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzes.map(quiz => {
              const quizQuestions = questions.filter(q => q.quizId === quiz.id);

              return (
                <div key={quiz.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-bold text-indigo-600">{quiz.category}</span>
                    <span className="font-mono">{quiz.durationMinutes} mins</span>
                  </div>

                  <h4 className="text-base font-bold text-slate-900">{quiz.title}</h4>
                  <p className="text-xs text-slate-600 line-clamp-2">{quiz.description}</p>

                  <div className="pt-3 border-t border-slate-100 text-xs font-mono text-slate-500 flex items-center justify-between">
                    <span>{quizQuestions.length} Questions</span>
                    <span>Pass: {quiz.passingPercentage}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. TAB 3: STUDENT RESULTS LEDGER */}
      {activeTab === 'results' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">Student Examination Ledger</h3>
              <p className="text-xs text-slate-500 mt-0.5">Records stored in MySQL <code className="font-mono text-xs">quiz_results</code> table.</p>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search by student name or roll..."
                value={searchStudentQuery}
                onChange={(e) => setSearchStudentQuery(e.target.value)}
                className="pl-9 pr-3.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:border-indigo-600 font-mono w-64"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-sans font-medium">
                  <th className="py-2.5 px-3">Roll No</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Quiz Title</th>
                  <th className="py-2.5 px-3 text-center">Score</th>
                  <th className="py-2.5 px-3 text-center">Percentage</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3 text-right">Submitted At</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {displayedResults.map(r => (
                  <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-3 font-bold text-slate-900">{r.studentRollNo}</td>
                    <td className="py-3 px-3 font-sans text-slate-700">{r.studentName}</td>
                    <td className="py-3 px-3 font-sans text-slate-600">{r.quizTitle}</td>
                    <td className="py-3 px-3 text-center font-bold">{r.scoreObtained}/{r.totalMarks}</td>
                    <td className="py-3 px-3 text-center font-bold">
                      <span className={r.isPassed ? 'text-emerald-600' : 'text-rose-600'}>
                        {r.percentage}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center font-sans">
                      {r.isPassed ? (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          PASSED
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                          FAILED
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right text-slate-400">{r.submittedAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. TAB 4: MYSQL SCHEMA & TABLES INSPECTOR */}
      {activeTab === 'db-inspector' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div>
            <h3 className="text-base font-bold text-slate-900">MySQL Database Schema Inspector</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Visualizes how frontend interactions translate to JDBC SQL queries and relational MySQL tables.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="font-bold text-purple-700 block mb-1">TABLE: students</span>
              <p className="text-slate-600 text-[11px] mb-2">Total Rows: {dbService.getStudents().length}</p>
              <pre className="text-[10px] text-slate-500 overflow-x-auto">
{`student_id INT PK AUTO_INC
roll_no VARCHAR(20) UNIQUE
full_name VARCHAR(100)
email VARCHAR(100) UNIQUE
password VARCHAR(255)
branch VARCHAR(50)
year_sem VARCHAR(20)`}
              </pre>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="font-bold text-indigo-700 block mb-1">TABLE: questions</span>
              <p className="text-slate-600 text-[11px] mb-2">Total Rows: {questions.length}</p>
              <pre className="text-[10px] text-slate-500 overflow-x-auto">
{`question_id INT PK AUTO_INC
quiz_id INT FK (quizzes)
question_text TEXT
option_a VARCHAR(255)
option_b VARCHAR(255)
option_c VARCHAR(255)
option_d VARCHAR(255)
correct_option CHAR(1)`}
              </pre>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="font-bold text-emerald-700 block mb-1">TABLE: quiz_results</span>
              <p className="text-slate-600 text-[11px] mb-2">Total Rows: {results.length}</p>
              <pre className="text-[10px] text-slate-500 overflow-x-auto">
{`result_id INT PK AUTO_INC
quiz_id INT FK
student_id INT FK
total_questions INT
correct_answers INT
score_obtained INT
percentage DECIMAL(5,2)
is_passed BOOLEAN`}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* 7. ADD / EDIT QUESTION MODAL */}
      {isQuestionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-slate-100 p-6 overflow-y-auto max-h-[90vh]">
            
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              {editingQuestionId ? 'Edit Examination Question' : 'Add Question to Question Bank'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Configures question text, four distinct options, and correct answer key for automated grading.
            </p>

            <form onSubmit={handleSaveQuestion} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Quiz</label>
                <select
                  value={qQuizId}
                  onChange={(e) => setQQuizId(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {quizzes.map(q => (
                    <option key={q.id} value={q.id}>{q.title}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Question Text *</label>
                <textarea
                  rows={2}
                  value={qText}
                  onChange={(e) => setQText(e.target.value)}
                  placeholder="Enter the examination question..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Code Snippet (Optional)</label>
                <textarea
                  rows={2}
                  value={qCodeSnippet}
                  onChange={(e) => setQCodeSnippet(e.target.value)}
                  placeholder="e.g. int x = 10; System.out.println(x);"
                  className="w-full px-3 py-2 bg-slate-900 text-slate-100 font-mono rounded-xl text-[11px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Option A *</label>
                  <input
                    type="text"
                    value={qOptA}
                    onChange={(e) => setQOptA(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Option B *</label>
                  <input
                    type="text"
                    value={qOptB}
                    onChange={(e) => setQOptB(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Option C *</label>
                  <input
                    type="text"
                    value={qOptC}
                    onChange={(e) => setQOptC(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Option D *</label>
                  <input
                    type="text"
                    value={qOptD}
                    onChange={(e) => setQOptD(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Correct Answer Key *</label>
                  <select
                    value={qCorrect}
                    onChange={(e) => setQCorrect(e.target.value as any)}
                    className="w-full px-3 py-2 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-800 font-bold"
                  >
                    <option value="A">Option A</option>
                    <option value="B">Option B</option>
                    <option value="C">Option C</option>
                    <option value="D">Option D</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Marks</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={qMarks}
                    onChange={(e) => setQMarks(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pedagogical Explanation</label>
                <textarea
                  rows={2}
                  value={qExplanation}
                  onChange={(e) => setQExplanation(e.target.value)}
                  placeholder="Explain why the chosen option is correct for the student review page..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsQuestionModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold shadow-xs"
                >
                  {editingQuestionId ? 'Update Question' : 'Save to MySQL Database'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* 8. CREATE QUIZ MODAL */}
      {isQuizModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 p-6">
            <h3 className="text-lg font-bold text-slate-900 mb-1">Create Examination Quiz</h3>
            <p className="text-xs text-slate-500 mb-4">Inserts a new record into MySQL <code className="font-mono">quizzes</code> table.</p>

            <form onSubmit={handleCreateQuiz} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Quiz Title *</label>
                <input
                  type="text"
                  placeholder="e.g. Operating Systems & Threads"
                  value={newQuizTitle}
                  onChange={(e) => setNewQuizTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Category / Department</label>
                <input
                  type="text"
                  placeholder="e.g. Computer Science"
                  value={newQuizCategory}
                  onChange={(e) => setNewQuizCategory(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Summary of topics covered..."
                  value={newQuizDesc}
                  onChange={(e) => setNewQuizDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Duration (Minutes)</label>
                  <input
                    type="number"
                    min={1}
                    max={120}
                    value={newQuizDuration}
                    onChange={(e) => setNewQuizDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Passing %</label>
                  <input
                    type="number"
                    min={10}
                    max={100}
                    value={newQuizPass}
                    onChange={(e) => setNewQuizPass(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsQuizModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold shadow-xs"
                >
                  Create Quiz
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
