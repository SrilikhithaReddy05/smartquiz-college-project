import React, { useState } from 'react';
import { 
  Play, 
  Clock, 
  Award, 
  CheckCircle2, 
  XCircle, 
  FileText, 
  BookOpen, 
  Sparkles, 
  AlertTriangle,
  RotateCcw,
  BarChart2,
  Calendar,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { Student, Quiz, QuizResult } from '../types/quiz';

interface StudentDashboardProps {
  student: Student;
  quizzes: Quiz[];
  results: QuizResult[];
  onStartQuiz: (quiz: Quiz) => void;
  onReviewResult: (result: QuizResult) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  student,
  quizzes,
  results,
  onStartQuiz,
  onReviewResult
}) => {
  const [selectedQuizForModal, setSelectedQuizForModal] = useState<Quiz | null>(null);

  // Compute student stats
  const totalAttempted = results.length;
  const averageScore = totalAttempted > 0
    ? Math.round(results.reduce((acc, r) => acc + r.percentage, 0) / totalAttempted)
    : 0;
  const bestScore = totalAttempted > 0
    ? Math.max(...results.map(r => r.percentage))
    : 0;
  const passedQuizzesCount = results.filter(r => r.isPassed).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fade-in">
      
      {/* 1. WELCOME BANNER */}
      <div className="relative overflow-hidden bg-gradient-to-r from-indigo-900 via-purple-900 to-indigo-950 rounded-3xl p-6 sm:p-8 text-white shadow-xl">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 pointer-events-none bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-white font-bold text-2xl backdrop-blur-sm shadow-inner">
              {student.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  Welcome back, {student.name}!
                </h1>
              </div>
              <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-purple-200">
                <span className="font-mono bg-white/10 px-2 py-0.5 rounded text-white">{student.rollNo}</span>
                <span aria-hidden="true">·</span>
                <span>{student.branch}</span>
                <span aria-hidden="true">·</span>
                <span>{student.year}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (quizzes.length > 0) setSelectedQuizForModal(quizzes[0]);
              }}
              className="px-5 py-2.5 bg-white text-indigo-900 hover:bg-purple-50 font-bold text-xs rounded-xl shadow-lg transition-transform hover:scale-102 flex items-center gap-2"
            >
              <Play className="w-4 h-4 fill-indigo-900" />
              Take Recommended Quiz
            </button>
          </div>
        </div>
      </div>

      {/* 2. STATS OVERVIEW CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-xs font-medium text-slate-500 mb-1">Total Attempted</div>
          <div className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {totalAttempted}
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Recorded in MySQL database
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-xs font-medium text-slate-500 mb-1">Average Score</div>
          <div className="text-3xl font-extrabold text-indigo-600 font-mono tabular-nums">
            {averageScore}%
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Across all submissions
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-xs font-medium text-slate-500 mb-1">Highest Score</div>
          <div className="text-3xl font-extrabold text-emerald-600 font-mono tabular-nums">
            {bestScore}%
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Personal best record
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-xs font-medium text-slate-500 mb-1">Tests Passed</div>
          <div className="text-3xl font-extrabold text-purple-600 font-mono tabular-nums">
            {passedQuizzesCount} <span className="text-sm font-normal text-slate-400">/ {totalAttempted}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Qualified with ≥ 50%
          </div>
        </div>

      </div>

      {/* 3. AVAILABLE QUIZZES GRID */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Available Quizzes</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Choose an exam to begin. Timers run continuously during the test.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz) => (
            <div 
              key={quiz.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
                  <span className="font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                    {quiz.category}
                  </span>
                  <span className="flex items-center gap-1 font-mono text-slate-600">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    {quiz.durationMinutes} mins
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 mb-2 leading-snug">
                  {quiz.title}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed mb-5 line-clamp-2">
                  {quiz.description}
                </p>
              </div>

              <div>
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 mb-4 font-mono">
                  <span>Marks: {quiz.totalMarks}</span>
                  <span>Pass: {quiz.passingPercentage}%</span>
                </div>

                <button
                  onClick={() => setSelectedQuizForModal(quiz)}
                  className="w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-colors flex items-center justify-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-white" />
                  Start Examination
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. RECENT QUIZ RESULTS TABLE */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight">Recent Quiz Results</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Detailed performance history stored in MySQL <code className="font-mono text-xs">quiz_results</code> table.
            </p>
          </div>
        </div>

        {results.length === 0 ? (
          <div className="text-center py-12 text-slate-400">
            <BookOpen className="w-10 h-10 mx-auto mb-2 opacity-50" />
            <p className="text-sm font-medium">No quiz attempts yet.</p>
            <p className="text-xs mt-1">Start any available quiz above to view your score analytics.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-medium">
                  <th className="py-3 px-3">Examination Name</th>
                  <th className="py-3 px-3">Date & Time</th>
                  <th className="py-3 px-3 text-center">Questions</th>
                  <th className="py-3 px-3 text-center">Score</th>
                  <th className="py-3 px-3 text-center">Percentage</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {results.map((res) => (
                  <tr key={res.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-sans font-semibold text-slate-900">
                      {res.quizTitle}
                    </td>
                    <td className="py-3 px-3 text-slate-500">
                      {res.submittedAt}
                    </td>
                    <td className="py-3 px-3 text-center text-slate-600">
                      {res.attemptedQuestions}/{res.totalQuestions}
                    </td>
                    <td className="py-3 px-3 text-center font-bold text-slate-900">
                      {res.scoreObtained}/{res.totalMarks}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`font-bold ${res.isPassed ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {res.percentage}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center font-sans">
                      {res.isPassed ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          PASSED
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                          <XCircle className="w-3 h-3 text-rose-600" />
                          FAILED
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right font-sans">
                      <button
                        onClick={() => onReviewResult(res)}
                        className="px-2.5 py-1 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors inline-flex items-center gap-1"
                      >
                        Review Answers
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 5. EXAMINATION INSTRUCTIONS MODAL */}
      {selectedQuizForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 p-6 overflow-hidden">
            
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  {selectedQuizForModal.title}
                </h3>
                <span className="text-xs text-slate-500">
                  Examination General Instructions
                </span>
              </div>
            </div>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 mb-5 text-xs text-slate-700 space-y-2.5 leading-relaxed">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200/80 font-mono">
                <span>Allocated Duration:</span>
                <span className="font-bold text-slate-900">{selectedQuizForModal.durationMinutes} Minutes (Live Timer)</span>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-200/80 font-mono">
                <span>Total Marks:</span>
                <span className="font-bold text-slate-900">{selectedQuizForModal.totalMarks} Marks</span>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-200/80 font-mono">
                <span>Passing Criteria:</span>
                <span className="font-bold text-emerald-700">{selectedQuizForModal.passingPercentage}% Required</span>
              </div>

              <div className="pt-2 text-[11px] text-slate-600 space-y-1.5 font-sans">
                <p>• Only <strong>one option</strong> can be selected per question.</p>
                <p>• The countdown timer continues running while switching questions.</p>
                <p>• You may mark questions for review and return at any time before timer expiry.</p>
                <p>• When the timer reaches <strong className="text-rose-600 font-mono">00:00</strong>, the examination will <strong>automatically submit</strong>.</p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setSelectedQuizForModal(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  const q = selectedQuizForModal;
                  setSelectedQuizForModal(null);
                  onStartQuiz(q);
                }}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-md shadow-indigo-200 transition-colors flex items-center gap-2"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                I Understand, Start Exam Now
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
