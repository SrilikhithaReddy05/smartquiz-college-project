import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  Clock, 
  Award, 
  RotateCcw, 
  ArrowLeft, 
  FileText, 
  Printer, 
  ChevronDown, 
  ChevronUp,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { QuizResult, Question, Quiz } from '../types/quiz';

interface ResultViewProps {
  result: QuizResult;
  quiz?: Quiz;
  questions: Question[];
  onRetakeQuiz: () => void;
  onGoToDashboard: () => void;
}

export const ResultView: React.FC<ResultViewProps> = ({
  result,
  quiz,
  questions,
  onRetakeQuiz,
  onGoToDashboard
}) => {
  const [filter, setFilter] = useState<'all' | 'correct' | 'incorrect' | 'unanswered'>('all');
  const [expandedExplanations, setExpandedExplanations] = useState<Record<number, boolean>>({});

  // Trigger celebration confetti on pass!
  useEffect(() => {
    if (result.isPassed) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (e) {
        // Fallback gracefully
      }
    }
  }, [result.isPassed]);

  const toggleExplanation = (qId: number) => {
    setExpandedExplanations(prev => ({ ...prev, [qId]: !prev[qId] }));
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m ${s.toString().padStart(2, '0')}s`;
  };

  // Filtered review questions
  const filteredQuestions = questions.filter(q => {
    const studentAnswer = result.answers[q.id];
    if (filter === 'correct') return studentAnswer === q.correctOption;
    if (filter === 'incorrect') return studentAnswer !== null && studentAnswer !== q.correctOption;
    if (filter === 'unanswered') return studentAnswer === null || studentAnswer === undefined;
    return true;
  });

  // Circular gauge calculations
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (result.percentage / 100) * circumference;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fade-in">
      
      {/* 1. SCORE HERO CARD WITH CIRCULAR GAUGE */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-10 shadow-sm overflow-hidden relative">
        
        {/* Subtle ambient gradient bar */}
        <div className={`h-2 absolute top-0 left-0 right-0 ${result.isPassed ? 'bg-gradient-to-r from-emerald-500 to-teal-500' : 'bg-gradient-to-r from-rose-500 to-amber-500'}`}></div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          
          {/* Left Details */}
          <div className="space-y-4 text-center md:text-left flex-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
              <span className="font-mono text-purple-700">MySQL Result ID: #{result.id}</span>
              <span aria-hidden="true">·</span>
              <span>{result.submittedAt}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              {result.quizTitle}
            </h1>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 text-xs text-slate-500 font-mono">
              <span>Candidate: <strong className="text-slate-800 font-sans">{result.studentName}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Roll: <strong className="text-slate-800">{result.studentRollNo}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Time: <strong className="text-slate-800">{formatSeconds(result.timeTakenSeconds)}</strong></span>
            </div>

            <div className="pt-2">
              {result.isPassed ? (
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>CONGRATULATIONS! YOU HAVE PASSED THE EXAMINATION</span>
                </div>
              ) : (
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-bold">
                  <XCircle className="w-4 h-4 text-rose-600" />
                  <span>NEEDS IMPROVEMENT - PASS MARK IS {quiz?.passingPercentage || 50}%</span>
                </div>
              )}
            </div>
          </div>

          {/* Right: Circular Score Gauge */}
          <div className="relative flex flex-col items-center justify-center shrink-0">
            <svg className="w-44 h-44 -rotate-90 transform" viewBox="0 0 160 160">
              {/* Background Track */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                className="stroke-slate-100"
                strokeWidth="12"
                fill="transparent"
              />
              {/* Progress Stroke */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                className={result.isPassed ? 'stroke-emerald-500' : 'stroke-rose-500'}
                strokeWidth="12"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                style={{ transition: 'stroke-dashoffset 1s ease-in-out' }}
              />
            </svg>

            {/* Inner Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-3xl font-extrabold text-slate-900 font-mono tracking-tight tabular-nums">
                {result.percentage}%
              </span>
              <span className="text-xs font-semibold text-slate-400 mt-0.5">
                {result.scoreObtained} / {result.totalMarks} Marks
              </span>
            </div>
          </div>

        </div>

        {/* 2. SUMMARY METRICS ROW */}
        <div className="mt-8 pt-8 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/70">
            <div className="text-[11px] font-medium text-slate-500">Total Questions</div>
            <div className="text-xl font-bold text-slate-900 font-mono mt-0.5">{result.totalQuestions}</div>
          </div>

          <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-200/70">
            <div className="text-[11px] font-medium text-emerald-800">Correct Answers</div>
            <div className="text-xl font-bold text-emerald-600 font-mono mt-0.5">{result.correctAnswers}</div>
          </div>

          <div className="p-3 bg-rose-50/60 rounded-2xl border border-rose-200/70">
            <div className="text-[11px] font-medium text-rose-800">Incorrect Answers</div>
            <div className="text-xl font-bold text-rose-600 font-mono mt-0.5">{result.incorrectAnswers}</div>
          </div>

          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/70">
            <div className="text-[11px] font-medium text-slate-500">Unanswered</div>
            <div className="text-xl font-bold text-slate-600 font-mono mt-0.5">{result.unansweredQuestions}</div>
          </div>

        </div>

      </div>

      {/* 3. ACTION BAR */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        
        <button
          onClick={onGoToDashboard}
          className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors flex items-center gap-1.5"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Student Dashboard
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" />
            Print Report
          </button>

          <button
            onClick={onRetakeQuiz}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className="w-4 h-4" />
            Retake Quiz
          </button>
        </div>

      </div>

      {/* 4. DETAILED QUESTION-BY-QUESTION REVIEW */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-sm">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight">
              Detailed Question Review
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Compare your selected options with correct answer keys and technical explanations.
            </p>
          </div>

          {/* Interactive filter tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All ({questions.length})
            </button>
            <button
              onClick={() => setFilter('correct')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                filter === 'correct' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Correct ({result.correctAnswers})
            </button>
            <button
              onClick={() => setFilter('incorrect')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                filter === 'incorrect' ? 'bg-white text-rose-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Incorrect ({result.incorrectAnswers})
            </button>
            <button
              onClick={() => setFilter('unanswered')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                filter === 'unanswered' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Skipped ({result.unansweredQuestions})
            </button>
          </div>
        </div>

        {/* Questions list */}
        <div className="divide-y divide-slate-100 mt-6">
          {filteredQuestions.map((q, idx) => {
            const studentAns = result.answers[q.id];
            const isCorrect = studentAns === q.correctOption;
            const isUnanswered = studentAns === null || studentAns === undefined;
            const isExpanded = expandedExplanations[q.id] !== false; // default open

            return (
              <div key={q.id} className="py-6 first:pt-0 last:pb-0 space-y-4">
                
                {/* Header with question status */}
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <span className="w-6 h-6 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center font-mono text-xs font-bold shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 leading-snug">
                        {q.questionText}
                      </h3>
                      {q.codeSnippet && (
                        <div className="mt-2 bg-slate-900 text-slate-100 rounded-xl p-3 font-mono text-xs overflow-x-auto">
                          <pre>{q.codeSnippet}</pre>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="shrink-0">
                    {isCorrect ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Correct (+{q.marks})
                      </span>
                    ) : isUnanswered ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200">
                        Unanswered (0)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200">
                        <XCircle className="w-3.5 h-3.5" />
                        Incorrect (0)
                      </span>
                    )}
                  </div>
                </div>

                {/* 4 Options Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 pl-9">
                  {(['A', 'B', 'C', 'D'] as const).map(optKey => {
                    const isRightAnswer = optKey === q.correctOption;
                    const isCandidateChoice = optKey === studentAns;

                    let cardStyle = 'border-slate-200 bg-white text-slate-700';
                    if (isRightAnswer) {
                      cardStyle = 'border-emerald-300 bg-emerald-50/70 text-emerald-950 font-medium ring-1 ring-emerald-400';
                    } else if (isCandidateChoice && !isRightAnswer) {
                      cardStyle = 'border-rose-300 bg-rose-50/70 text-rose-950 line-through';
                    }

                    return (
                      <div 
                        key={optKey} 
                        className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${cardStyle}`}
                      >
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 ${
                          isRightAnswer
                            ? 'bg-emerald-600 text-white'
                            : isCandidateChoice
                            ? 'bg-rose-600 text-white'
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {optKey}
                        </span>
                        <div className="flex-1">
                          <span>{q.options[optKey]}</span>
                          {isRightAnswer && (
                            <span className="block text-[10px] text-emerald-700 font-semibold mt-0.5">
                              ✓ Correct Answer
                            </span>
                          )}
                          {isCandidateChoice && !isRightAnswer && (
                            <span className="block text-[10px] text-rose-600 font-semibold mt-0.5">
                              ✗ Your Choice
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Technical Explanation Box */}
                <div className="pl-9 pt-2">
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 text-xs text-slate-700 leading-relaxed">
                    <div className="font-semibold text-slate-900 mb-1 flex items-center gap-1.5">
                      <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
                      Pedagogical Explanation:
                    </div>
                    <p className="text-slate-600">
                      {q.explanation}
                    </p>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
