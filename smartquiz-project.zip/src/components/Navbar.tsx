import React from 'react';
import { 
  GraduationCap, 
  Code2, 
  ShieldCheck, 
  LogOut, 
  User, 
  BookOpen, 
  Sparkles,
  LayoutDashboard
} from 'lucide-react';
import { Student, Admin, ViewState } from '../types/quiz';

interface NavbarProps {
  currentView: ViewState;
  setCurrentView: (view: ViewState) => void;
  currentStudent: Student | null;
  currentAdmin: Admin | null;
  onOpenAuth: (defaultTab?: 'student-login' | 'student-register' | 'admin-login') => void;
  onOpenProjectHub: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  currentStudent,
  currentAdmin,
  onOpenAuth,
  onOpenProjectHub,
  onLogout
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Wordmark */}
        <button 
          onClick={() => setCurrentView('home')}
          className="flex items-center gap-2.5 text-left group focus:outline-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md shadow-indigo-200 group-hover:scale-105 transition-transform">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xl font-bold tracking-tight text-slate-900 group-hover:text-indigo-600 transition-colors whitespace-nowrap">
              SmartQuiz
            </span>
            <span className="hidden sm:inline-block text-[11px] font-medium text-slate-400 ml-2 border-l border-slate-200 pl-2">
              Online Examination Portal
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links (Single-line, clean unboxed) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setCurrentView('home')}
            className={`transition-colors whitespace-nowrap hover:text-indigo-600 ${
              currentView === 'home' ? 'text-indigo-600 font-semibold' : ''
            }`}
          >
            Home
          </button>

          {currentStudent && (
            <button
              onClick={() => setCurrentView('student-dashboard')}
              className={`transition-colors whitespace-nowrap flex items-center gap-1.5 hover:text-indigo-600 ${
                currentView === 'student-dashboard' ? 'text-indigo-600 font-semibold' : ''
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              Student Dashboard
            </button>
          )}

          {currentAdmin && (
            <button
              onClick={() => setCurrentView('admin-dashboard')}
              className={`transition-colors whitespace-nowrap flex items-center gap-1.5 hover:text-indigo-600 ${
                currentView === 'admin-dashboard' ? 'text-indigo-600 font-semibold' : ''
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-purple-600" />
              Admin Portal
            </button>
          )}

          <button
            onClick={onOpenProjectHub}
            className="flex items-center gap-1.5 text-indigo-700 hover:text-indigo-900 transition-colors whitespace-nowrap font-medium"
          >
            <Code2 className="w-4 h-4 text-indigo-600" />
            Java & SQL Source Code
          </button>
        </nav>

        {/* Zone 3: Primary Action / User Profile */}
        <div className="flex items-center gap-3 shrink-0">
          {currentStudent ? (
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentView('student-dashboard')}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-colors text-left"
              >
                <div className="w-8 h-8 rounded-full bg-indigo-100 border border-indigo-200 flex items-center justify-center text-indigo-700 font-semibold text-xs">
                  {currentStudent.name.charAt(0)}
                </div>
                <div className="hidden lg:block">
                  <div className="text-xs font-semibold text-slate-900 truncate max-w-[120px]">
                    {currentStudent.name}
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">
                    {currentStudent.rollNo}
                  </div>
                </div>
              </button>

              <button
                onClick={onLogout}
                title="Logout"
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : currentAdmin ? (
            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentView('admin-dashboard')}
                className="flex items-center gap-2 px-3 py-1.5 bg-purple-50 border border-purple-200 rounded-lg text-purple-800 text-xs font-semibold hover:bg-purple-100 transition-colors"
              >
                <ShieldCheck className="w-4 h-4 text-purple-600" />
                <span className="hidden sm:inline">Admin Mode</span>
              </button>

              <button
                onClick={onLogout}
                title="Logout"
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenAuth('student-login')}
                className="px-3.5 py-2 text-xs font-medium text-slate-700 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors whitespace-nowrap"
              >
                Sign In
              </button>
              <button
                onClick={() => onOpenAuth('student-register')}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-200 transition-colors whitespace-nowrap"
              >
                Student Register
              </button>
            </div>
          )}
        </div>

      </div>
    </header>
  );
};
