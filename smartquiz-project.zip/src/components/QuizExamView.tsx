import React, { useState, useEffect, useRef } from 'react';
import { 
  Timer, 
  ChevronLeft, 
  ChevronRight, 
  Bookmark, 
  CheckCircle2, 
  AlertCircle, 
  Send, 
  RotateCcw, 
  HelpCircle,
  Clock,
  ShieldAlert
} from 'lucide-react';
import { Quiz, Question, Student } from '../types/quiz';

interface QuizExamViewProps {
  quiz: Quiz;
  questions: Question[];
  student: Student;
  onSubmitExam: (answers: Record<number, 'A' | 'B' | 'C' | 'D' | null>, timeSpentSeconds: number) => void;
  onExitWithoutSaving: () => void;
}

export const QuizExamView: React.FC<QuizExamViewProps> = ({
  quiz,
  questions,
  student,
  onSubmitExam,
  onExitWithoutSaving,
}) => {
  // Current question index (0-indexed)
  const [currentIndex, setCurrentIndex] = useState(0);

  // Answers map: questionId -> 'A' | 'B' | 'C' | 'D' | null
  const [answers, setAnswers] = useState<Record<number, 'A' | 'B' | 'C' | 'D' | null>>(() => {
    const initial: Record<number, 'A' | 'B' | 'C' | 'D' | null> = {};
    questions.forEach(q => { initial[q.id] = null; });
    return initial;
  });

  // Marked for review map: questionId -> boolean
  const [markedForReview, setMarkedForReview] = useState<Record<number, boolean>>({});

  // Countdown timer state in seconds
  const totalDurationSeconds = quiz.durationMinutes * 60;
  const [secondsRemaining, setSecondsRemaining] = useState(totalDurationSeconds);
  const [isTimeUp, setIsTimeUp] = useState(false);

  // Submit confirmation modal
  const [showSubmitModal, setShowSubmitModal] = useState(false);

  // Track start time
  const startTimeRef = useRef<number>(Date.now());
  const timerIntervalRef = useRef<any>(null);

  // 1. LIVE COUNTDOWN TIMER ENGINE
  useEffect(() => {
    timerIntervalRef.current = setInterval(() => {
      setSecondsRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timerIntervalRef.current);
          setIsTimeUp(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
    };
  }, []);

  // 2. AUTOMATIC SUBMISSION ON TIMER EXPIRY
  useEffect(() => {
    if (isTimeUp) {
      // Trigger auto-submit
      const timeSpent = totalDurationSeconds;
      onSubmitExam(answers, timeSpent);
    }
  }, [isTimeUp]);

  // Format MM:SS
  const formatTimer = (totalSecs: number) => {
    const m = Math.floor(totalSecs / 60);
    const s = totalSecs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Keyboard shortcut listener (1-4 or A-D for options, Arrows for Prev/Next)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (showSubmitModal) return;

      const currentQ = questions[currentIndex];
      if (!currentQ) return;

      const key = e.key.toUpperCase();
      if (['A', 'B', 'C', 'D'].includes(key)) {
        handleSelectOption(key as 'A' | 'B' | 'C' | 'D');
      } else if (key === '1') {
        handleSelectOption('A');
      } else if (key === '2') {
        handleSelectOption('B');
      } else if (key === '3') {
        handleSelectOption('C');
      } else if (key === '4') {
        handleSelectOption('D');
      } else if (e.key === 'ArrowRight' && currentIndex < questions.length - 1) {
        setCurrentIndex(prev => prev + 1);
      } else if (e.key === 'ArrowLeft' && currentIndex > 0) {
        setCurrentIndex(prev => prev - 1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, questions, showSubmitModal]);

  const currentQuestion = questions[currentIndex];

  const handleSelectOption = (opt: 'A' | 'B' | 'C' | 'D') => {
    if (!currentQuestion) return;
    setAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: opt
    }));
  };

  const handleClearSelection = () => {
    if (!currentQuestion) return;
    setAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: null
    }));
  };

  const handleToggleMarkForReview = () => {
    if (!currentQuestion) return;
    setMarkedForReview(prev => ({
      ...prev,
      [currentQuestion.id]: !prev[currentQuestion.id]
    }));
  };

  // Metrics for question palette
  const answeredCount = Object.values(answers).filter(Boolean).length;
  const markedCount = Object.values(markedForReview).filter(Boolean).length;
  const unansweredCount = questions.length - answeredCount;
  const progressPercent = Math.round(((currentIndex + 1) / questions.length) * 100);

  // Timer color classification
  const isUrgent = secondsRemaining < 60; // < 1 minute (red pulse)
  const isWarning = secondsRemaining < 180 && !isUrgent; // < 3 minutes (amber)

  const handleFinalSubmit = () => {
    const timeSpent = Math.min(
      totalDurationSeconds,
      Math.round((Date.now() - startTimeRef.current) / 1000)
    );
    onSubmitExam(answers, timeSpent);
  };

  return (
    <div className="min-h-screen bg-slate-100/90 text-slate-800 flex flex-col pb-12">
      
      {/* 1. TOP EXAMINATION STICKY HEADER */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          {/* Quiz Details */}
          <div className="flex items-center gap-3 truncate">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
            <div className="truncate">
              <h2 className="text-sm font-bold text-slate-900 truncate">
                {quiz.title}
              </h2>
              <div className="text-[11px] text-slate-500 flex items-center gap-2">
                <span>{student.name} ({student.rollNo})</span>
                <span aria-hidden="true">·</span>
                <span className="hidden sm:inline">Single Choice Examination</span>
              </div>
            </div>
          </div>

          {/* LIVE TIMER CLOCK (MM:SS) */}
          <div className="flex items-center gap-3 shrink-0">
            <div 
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl border font-mono font-bold transition-all text-sm ${
                isUrgent
                  ? 'bg-rose-50 border-rose-300 text-rose-700 animate-pulse shadow-sm shadow-rose-200'
                  : isWarning
                  ? 'bg-amber-50 border-amber-300 text-amber-700'
                  : 'bg-indigo-50 border-indigo-200 text-indigo-700'
              }`}
            >
              <Timer className={`w-4 h-4 ${isUrgent ? 'animate-spin' : ''}`} />
              <div className="flex flex-col text-right">
                <span className="text-xs uppercase tracking-wider text-slate-500 text-[9px] font-sans">
                  Time Remaining
                </span>
                <span className="text-base sm:text-lg leading-none tabular-nums">
                  {formatTimer(secondsRemaining)}
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowSubmitModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-colors flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Submit Test</span>
            </button>
          </div>

        </div>

        {/* Global Progress Bar */}
        <div className="w-full bg-slate-200 h-1">
          <div 
            className="bg-indigo-600 h-1 transition-all duration-300 ease-out"
            style={{ width: `${((answeredCount) / questions.length) * 100}%` }}
          ></div>
        </div>
      </header>

      {/* Low time floating alert */}
      {isUrgent && (
        <div className="bg-rose-600 text-white text-xs font-semibold py-1.5 px-4 text-center animate-bounce flex items-center justify-center gap-2">
          <ShieldAlert className="w-4 h-4" />
          <span>Hurry up! Less than 1 minute remaining. Exam will submit automatically at 00:00!</span>
        </div>
      )}

      {/* 2. MAIN EXAMINATION WORKSPACE */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 flex-1 w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT / CENTER: QUESTION CARD (8 Cols on Desktop) */}
        <main className="lg:col-span-8 space-y-4">
          
          <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-sm">
            
            {/* Question Top Info */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-indigo-50 border border-indigo-200 rounded-lg text-xs font-bold text-indigo-700 font-mono">
                  Question {currentIndex + 1} of {questions.length}
                </span>
                <span className="text-xs text-slate-400">
                  [{currentQuestion?.marks || 1} Mark]
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleToggleMarkForReview}
                  className={`flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-medium border transition-colors ${
                    markedForReview[currentQuestion?.id]
                      ? 'bg-amber-50 border-amber-300 text-amber-700 font-semibold'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${markedForReview[currentQuestion?.id] ? 'fill-amber-600 text-amber-600' : ''}`} />
                  <span>{markedForReview[currentQuestion?.id] ? 'Marked for Review' : 'Mark for Review'}</span>
                </button>

                {answers[currentQuestion?.id] && (
                  <button
                    onClick={handleClearSelection}
                    className="text-xs text-slate-400 hover:text-rose-600 px-2 py-1 transition-colors"
                    title="Clear current selection"
                  >
                    Clear Choice
                  </button>
                )}
              </div>
            </div>

            {/* Question Content */}
            {currentQuestion ? (
              <div className="space-y-6">
                
                <h3 className="text-base sm:text-lg font-semibold text-slate-900 leading-relaxed">
                  {currentQuestion.questionText}
                </h3>

                {/* Optional Code Snippet block */}
                {currentQuestion.codeSnippet && (
                  <div className="bg-slate-900 text-slate-100 rounded-xl p-4 font-mono text-xs overflow-x-auto border border-slate-800 shadow-inner">
                    <pre>{currentQuestion.codeSnippet}</pre>
                  </div>
                )}

                {/* 4 Answer Options */}
                <div className="space-y-3 pt-2">
                  {(['A', 'B', 'C', 'D'] as const).map((optKey) => {
                    const isSelected = answers[currentQuestion.id] === optKey;
                    const optText = currentQuestion.options[optKey];

                    return (
                      <button
                        key={optKey}
                        onClick={() => handleSelectOption(optKey)}
                        className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-3.5 cursor-pointer group ${
                          isSelected
                            ? 'bg-indigo-50/80 border-indigo-600 ring-2 ring-indigo-500/20 shadow-xs'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/70'
                        }`}
                      >
                        {/* Option Radio Circle */}
                        <div 
                          className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 transition-colors ${
                            isSelected
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 text-slate-600 group-hover:bg-slate-200'
                          }`}
                        >
                          {optKey}
                        </div>

                        {/* Option Text */}
                        <span className={`text-sm leading-relaxed ${isSelected ? 'font-semibold text-indigo-950' : 'text-slate-700'}`}>
                          {optText}
                        </span>
                      </button>
                    );
                  })}
                </div>

              </div>
            ) : (
              <div className="py-12 text-center text-slate-400">
                Question not found.
              </div>
            )}

            {/* Bottom Question Controls */}
            <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-between gap-4">
              
              <button
                onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
                disabled={currentIndex === 0}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:hover:bg-white transition-colors flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                Previous Question
              </button>

              <div className="hidden sm:block text-xs text-slate-400">
                Press <kbd className="px-1.5 py-0.5 bg-slate-100 border rounded font-mono text-[10px]">A</kbd>
                <kbd className="px-1.5 py-0.5 bg-slate-100 border rounded font-mono text-[10px] ml-1">B</kbd>
                <kbd className="px-1.5 py-0.5 bg-slate-100 border rounded font-mono text-[10px] ml-1">C</kbd>
                <kbd className="px-1.5 py-0.5 bg-slate-100 border rounded font-mono text-[10px] ml-1">D</kbd> to select
              </div>

              {currentIndex < questions.length - 1 ? (
                <button
                  onClick={() => setCurrentIndex(prev => Math.min(questions.length - 1, prev + 1))}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-sm transition-colors flex items-center gap-1.5"
                >
                  Save & Next
                  <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={() => setShowSubmitModal(true)}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm transition-colors flex items-center gap-1.5"
                >
                  Review & Submit
                  <Send className="w-3.5 h-3.5" />
                </button>
              )}

            </div>

          </div>

        </main>

        {/* RIGHT: QUESTION NAVIGATION PALETTE (4 Cols on Desktop) */}
        <aside className="lg:col-span-4 space-y-4">
          
          <div className="bg-white rounded-3xl border border-slate-200/90 p-5 shadow-sm">
            
            <h4 className="text-sm font-bold text-slate-900 mb-4 pb-3 border-b border-slate-100 flex items-center justify-between">
              <span>Question Palette</span>
              <span className="text-xs font-normal text-slate-500 font-mono">
                {answeredCount}/{questions.length} Answered
              </span>
            </h4>

            {/* Status Legend (Strictly clean and unboxed) */}
            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 mb-5 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded-md bg-emerald-600 shrink-0"></span>
                <span>Answered ({answeredCount})</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded-md bg-amber-500 shrink-0"></span>
                <span>Marked ({markedCount})</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded-md bg-indigo-600 ring-2 ring-indigo-300 shrink-0"></span>
                <span>Current ({currentIndex + 1})</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded-md bg-slate-100 border border-slate-300 shrink-0"></span>
                <span>Unattempted ({unansweredCount})</span>
              </div>
            </div>

            {/* Clickable Question Grid (1 to N) */}
            <div className="grid grid-cols-5 gap-2.5 mb-6">
              {questions.map((q, idx) => {
                const isCurrent = idx === currentIndex;
                const isAnswered = answers[q.id] !== null;
                const isMarked = markedForReview[q.id];

                let btnClass = 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200';
                if (isMarked) {
                  btnClass = 'bg-amber-500 text-white font-bold border-amber-600';
                } else if (isAnswered) {
                  btnClass = 'bg-emerald-600 text-white font-bold border-emerald-700';
                }

                if (isCurrent) {
                  btnClass += ' ring-2 ring-indigo-600 ring-offset-2 scale-105';
                }

                return (
                  <button
                    key={q.id}
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-10 rounded-xl font-mono text-xs flex items-center justify-center transition-all cursor-pointer ${btnClass}`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>

            {/* Submit Action */}
            <button
              onClick={() => setShowSubmitModal(true)}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              Final Submission
            </button>

            <button
              onClick={onExitWithoutSaving}
              className="w-full mt-2 py-2 text-slate-400 hover:text-slate-600 text-xs transition-colors"
            >
              Cancel & Return to Dashboard
            </button>

          </div>

        </aside>

      </div>

      {/* 3. CONFIRMATION MODAL BEFORE SUBMIT */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 p-6 overflow-hidden">
            
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center mb-4">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <h3 className="text-xl font-bold text-slate-900 mb-1">
              Submit Examination?
            </h3>
            <p className="text-xs text-slate-500 mb-5">
              Review your progress before finalizing. Once submitted, your answers will be evaluated and saved to MySQL.
            </p>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 mb-6 space-y-2.5 font-mono text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200/80">
                <span className="text-slate-600">Total Questions:</span>
                <span className="font-bold text-slate-900">{questions.length}</span>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-200/80">
                <span className="text-emerald-700 font-semibold">Answered:</span>
                <span className="font-bold text-emerald-700">{answeredCount}</span>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-200/80">
                <span className="text-amber-700 font-semibold">Marked for Review:</span>
                <span className="font-bold text-amber-700">{markedCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-rose-600 font-semibold">Unanswered:</span>
                <span className="font-bold text-rose-600">{unansweredCount}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowSubmitModal(false)}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100 transition-colors"
              >
                Back to Exam
              </button>
              <button
                type="button"
                onClick={handleFinalSubmit}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                Yes, Submit Final Exam
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
