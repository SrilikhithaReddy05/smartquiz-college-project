import React from 'react';
import { 
  Timer, 
  CheckCircle2, 
  BarChart3, 
  ShieldAlert, 
  Layers, 
  ArrowRight, 
  BookOpen, 
  Code2, 
  Database, 
  Server, 
  Play, 
  Sparkles,
  Award,
  Terminal,
  HelpCircle
} from 'lucide-react';
import { Quiz, Student } from '../types/quiz';

interface LandingPageProps {
  quizzes: Quiz[];
  currentStudent: Student | null;
  onSelectQuiz: (quiz: Quiz) => void;
  onOpenAuth: (tab?: 'student-login' | 'student-register' | 'admin-login') => void;
  onOpenProjectHub: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  quizzes,
  currentStudent,
  onSelectQuiz,
  onOpenAuth,
  onOpenProjectHub,
}) => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-900 text-white py-18 md:py-24">
        {/* Decorative ambient background blur */}
        <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#818cf8_1px,transparent_1px)] [background-size:24px_24px]"></div>
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          
          {/* Academic Project Kicker */}
          <div className="inline-flex items-center gap-2 px-3 py-1 text-xs font-semibold tracking-wide text-purple-200 bg-white/10 rounded-full border border-white/15 backdrop-blur-sm mb-6">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>B.Tech 2-1 Semester Mini Project · Computer Science & Engineering</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white max-w-4xl mx-auto text-balance leading-tight">
            Test Your Knowledge. <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-purple-200 via-indigo-200 to-amber-200 bg-clip-text text-transparent">
              Track Your Progress.
            </span>
          </h1>

          <p className="mt-6 text-base sm:text-lg text-purple-100/90 max-w-2xl mx-auto leading-relaxed">
            A complete, interactive online examination platform featuring a synchronized real-time countdown timer, dynamic question palette, automatic evaluation, and full Java Servlet & MySQL backend architecture.
          </p>

          {/* Action CTAs */}
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => {
                if (quizzes.length > 0) {
                  onSelectQuiz(quizzes[0]);
                }
              }}
              className="px-6 py-3.5 text-sm font-semibold text-indigo-950 bg-white hover:bg-purple-50 rounded-xl shadow-lg shadow-purple-950/40 hover:scale-102 transition-all flex items-center gap-2"
            >
              <Play className="w-4 h-4 fill-indigo-950" />
              Start Sample Quiz Now
            </button>

            {currentStudent ? (
              <button
                onClick={() => {
                  if (quizzes.length > 0) onSelectQuiz(quizzes[0]);
                }}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-indigo-600/80 hover:bg-indigo-600 border border-white/20 rounded-xl backdrop-blur-sm transition-all flex items-center gap-2"
              >
                Go to Dashboard
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => onOpenAuth('student-login')}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl backdrop-blur-sm transition-all flex items-center gap-2"
              >
                Student Sign In
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={onOpenProjectHub}
              className="px-5 py-3.5 text-sm font-medium text-purple-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors flex items-center gap-2"
            >
              <Code2 className="w-4 h-4 text-purple-300" />
              View Java & SQL Code
            </button>
          </div>

          {/* Tech Stack Unboxed Strip */}
          <div className="mt-14 pt-8 border-t border-white/10 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-purple-200/80">
            <span className="font-semibold text-white">Full Stack Specs:</span>
            <span>HTML5 & CSS3</span>
            <span aria-hidden="true">·</span>
            <span>JavaScript ES6+</span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-200 font-medium">Java Servlets (HttpServlet)</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-300 font-medium">JDBC PreparedStatement</span>
            <span aria-hidden="true">·</span>
            <span className="text-cyan-200 font-medium">MySQL 8.0 Database</span>
            <span aria-hidden="true">·</span>
            <span>Apache Tomcat 9/10</span>
          </div>

        </div>
      </section>

      {/* 2. CORE FEATURES SECTION */}
      <section className="py-16 md:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Designed for Real College Examination Standards
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600">
            SmartQuiz integrates every core requirement for university level competitive tests, mock GATE/NPTEL examinations, and academic assessments.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Feature 1 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-5">
              <Timer className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Synchronized Live Countdown
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Real-time timer in <span className="font-mono text-purple-700 font-medium">MM:SS</span> format. Runs uninterrupted while traversing questions, features visual color shifts when time is running low, and automatically submits when zero is reached.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-5">
              <Layers className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Interactive Question Palette
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Navigate instantly between questions with color-coded status badges: Answered (emerald), Marked for Review (amber), Current (indigo), and Not Attempted (slate).
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-5">
              <BarChart3 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Instant Results & Review
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Circular accuracy gauge, percentage calculator, Pass/Fail decision, and detailed question-by-question review with pedagogical explanations for every option.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-5">
              <Database className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              MySQL & JDBC Architecture
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Standardized relational schema across 6 normalized tables (<code className="text-xs bg-slate-100 px-1 py-0.5 rounded">students</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">quizzes</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">questions</code>, <code className="text-xs bg-slate-100 px-1 py-0.5 rounded">quiz_results</code>) using JDBC PreparedStatement.
            </p>
          </div>

          {/* Feature 5 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-5">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              Admin Question Management
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Faculty & Exam Controller dashboard to add multiple-choice questions, specify answer keys, edit durations, and review student performance records.
            </p>
          </div>

          {/* Feature 6 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center mb-5">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">
              B.Tech Mini Project Ready
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Accompanied by 15 high-frequency Viva Voce questions & answers, Tomcat deployment configuration guide, and clean modular code for effortless college evaluation.
            </p>
          </div>

        </div>
      </section>

      {/* 3. AVAILABLE QUIZZES CATALOG */}
      <section className="py-16 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
                Examination Catalog
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
                Available Departmental Quizzes
              </h2>
            </div>
            <p className="text-sm text-slate-500 max-w-md">
              Select any test below to launch the live examination environment with full timer synchronization.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzes.map((quiz) => (
              <div 
                key={quiz.id}
                className="bg-slate-50 border border-slate-200/90 rounded-2xl p-6 flex flex-col justify-between hover:border-indigo-300 hover:shadow-md transition-all group"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
                    <span className="font-semibold text-indigo-700">{quiz.category}</span>
                    <span className="flex items-center gap-1 font-mono">
                      <Timer className="w-3.5 h-3.5 text-slate-400" />
                      {quiz.durationMinutes} mins
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors mb-2">
                    {quiz.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed mb-6">
                    {quiz.description}
                  </p>
                </div>

                <div>
                  <div className="pt-4 border-t border-slate-200/70 flex items-center justify-between text-xs text-slate-500 mb-4">
                    <span>Pass: {quiz.passingPercentage}%</span>
                    <span>Total: {quiz.totalMarks} Marks</span>
                  </div>

                  <button
                    onClick={() => onSelectQuiz(quiz)}
                    className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-sm shadow-indigo-100 flex items-center justify-center gap-2 transition-colors"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" />
                    Take Examination
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 4. WORKFLOW / HOW IT WORKS */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            How The Online Examination Works
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            A three-step streamlined flow for students and faculty.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="text-center p-6 bg-white rounded-2xl border border-slate-200">
            <div className="w-12 h-12 mx-auto rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center font-bold text-base mb-4">
              01
            </div>
            <h4 className="text-base font-bold text-slate-900 mb-2">Student Authentication</h4>
            <p className="text-xs sm:text-sm text-slate-600">
              Students login with their unique Roll Number or Register. Sessions are securely maintained via Java <code className="text-xs font-mono">HttpSession</code>.
            </p>
          </div>

          <div className="text-center p-6 bg-white rounded-2xl border border-slate-200">
            <div className="w-12 h-12 mx-auto rounded-full bg-purple-50 border border-purple-200 text-purple-700 flex items-center justify-center font-bold text-base mb-4">
              02
            </div>
            <h4 className="text-base font-bold text-slate-900 mb-2">Live Examination</h4>
            <p className="text-xs sm:text-sm text-slate-600">
              Solve multiple choice questions with an active countdown timer. Jump freely using the question palette or mark questions for later review.
            </p>
          </div>

          <div className="text-center p-6 bg-white rounded-2xl border border-slate-200">
            <div className="w-12 h-12 mx-auto rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center font-bold text-base mb-4">
              03
            </div>
            <h4 className="text-base font-bold text-slate-900 mb-2">Automated Evaluation</h4>
            <p className="text-xs sm:text-sm text-slate-600">
              On manual submit or timer expiration, Java Servlets evaluate scores, persist records in MySQL, and generate instantaneous question reviews.
            </p>
          </div>

        </div>
      </section>

      {/* 5. FOOTER */}
      <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800 text-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <div className="text-white font-bold text-base flex items-center justify-center md:justify-start gap-2">
              <span className="w-3 h-3 rounded-full bg-indigo-500"></span>
              SmartQuiz Examination Portal
            </div>
            <p className="text-xs text-slate-500 mt-1">
              B.Tech 2-1 Semester College Mini Project · Java Servlets, JDBC, MySQL & Tomcat
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
            <button 
              onClick={onOpenProjectHub}
              className="hover:text-white transition-colors"
            >
              Java Code Center
            </button>
            <button 
              onClick={() => onOpenAuth('admin-login')}
              className="hover:text-purple-300 transition-colors"
            >
              Exam Controller Login
            </button>
            <button 
              onClick={() => onOpenAuth('student-login')}
              className="hover:text-white transition-colors"
            >
              Student Portal
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
};
