# SmartQuiz Netlify Deployment & Complete Source Code Export Plan

A comprehensive plan to package, configure, and export the entire SmartQuiz interactive examination website for seamless hosting on Netlify with zero loss of existing features, accompanied by a step-by-step Git export guide and local archive instructions.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following deployment and export preferences have been confirmed through Phase 1 clarification:

- **Confirmed Target Platform**: **Netlify only**. We will configure production build settings, publish directories (`dist`), and SPA single-page rewrite rules (`/*  /index.html  200`) specifically for Netlify via `netlify.toml` and `public/_redirects`.
- **Confirmed Export Workflow**: **Step-by-step Git export & deployment guide**. We will provide clear, beginner-friendly instructions for initializing Git, pushing to GitHub/GitLab, connecting to Netlify, and generating a local `.zip` file of the clean codebase.
- **Zero Regression Guarantee**: No existing exam timers, question palettes, score gauges, admin portals, or Java/SQL mini-project resources will be modified or removed.

---

### 1. Overview & Core Concept

- **What It Does**: Packages the full SmartQuiz web application—including all React 19 / TypeScript components, Tailwind CSS styling, simulated MySQL persistence engine, and the College Mini Project Java/SQL center—into a clean, standalone repository that builds with `npm run build` and deploys to Netlify with a single click.
- **Target Audience**: 2-1 semester B.Tech engineering student preparing for academic review, project submission, and live online hosting on Netlify.
- **Key Value**: A production-ready project that builds cleanly with zero errors on Netlify's CI/CD pipeline while allowing the student to retain, version, and download their complete source code via Git and ZIP archives.

---

### 2. User Experience & Visual Design

- **Export Readiness**: The application continues to run in the current browser preview without any visual disruption.
- **Netlify Configuration Files**:
  - `netlify.toml`: Defines the build command (`npm run build`), publish directory (`dist`), and redirect rules for client-side routing.
  - `public/_redirects`: Provides standard Netlify fallback (`/*  /index.html  200`) to ensure reloading pages never yields a 404 error.
  - `README.md`: Includes detailed step-by-step documentation for cloning, building, running locally, and deploying to Netlify.
- **Source Code Completeness**:
  - `src/App.tsx` & Root Layout
  - `src/components/`: `Navbar.tsx`, `LandingPage.tsx`, `AuthModal.tsx`, `StudentDashboard.tsx`, `QuizExamView.tsx`, `ResultView.tsx`, `AdminDashboard.tsx`, `ProjectHubModal.tsx`
  - `src/types/quiz.ts` & `src/data/initialData.ts`
  - `src/data/javaProjectCode.ts` (Servlets, JDBC, `smartquiz.sql`, Tomcat setup guide)
  - `src/services/dbService.ts`
  - Configs: `package.json`, `tsconfig.json`, `vite.config.ts`, `index.html`

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Netlify Client-Side SPA Redirects**
  - *Chosen Approach*: Add both `netlify.toml` and `public/_redirects` with `/* /index.html 200`.
  - *Why*: Netlify needs an explicit rewrite rule so that direct URLs, reloads, and browser history do not trigger default Netlify 404 pages.
- **Decision 2: Standalone Local ZIP File Creation**
  - *Chosen Approach*: Generate a clean `smartquiz-project.zip` file directly in the root workspace using system compression (excluding `node_modules` and `.git` to keep file size lightweight ~1MB).
  - *Why*: Gives the student an immediate file they can store, copy to a USB flash drive, or attach in their college submission portal.
- **Decision 3: Git & Netlify Documentation in Project Hub**
  - *Chosen Approach*: Add an export & Netlify deployment tab directly inside the in-app "Java & SQL Source Code" hub so instructions are accessible right from the UI at all times.

---

### 4. Technical Architecture & Data Strategy

```
┌──────────────────────────────────────────────────────────────────┐
│                     SMARTQUIZ SOURCE REPOSITORY                  │
│                                                                  │
│  ├── public/                                                     │
│  │   └── _redirects            <- Netlify SPA routing rewrite    │
│  ├── src/                                                        │
│  │   ├── components/           <- 8 full interactive views       │
│  │   ├── data/                 <- Quizzes, questions, Java code  │
│  │   ├── services/             <- Simulated MySQL/JDBC engine    │
│  │   └── types/                <- TypeScript interfaces          │
│  ├── index.html                <- Font pairings & entry HTML     │
│  ├── netlify.toml              <- Netlify build & headers config │
│  ├── package.json              <- Build dependencies & scripts   │
│  ├── tsconfig.json             <- TypeScript 5.8 / ES2022        │
│  ├── vite.config.ts            <- Tailwind v4 & Vite build       │
│  └── README.md                 <- Step-by-step Git & run guide   │
└─────────────────────────────────┬────────────────────────────────┘
                                  │
                                  ▼ Git Push / Drag-and-Drop
┌──────────────────────────────────────────────────────────────────┐
│                       NETLIFY PRODUCTION CI/CD                   │
│                                                                  │
│  Build Command:     npm run build                                │
│  Publish Directory: dist                                         │
│  Routing Policy:    /* -> /index.html 200 (Single Page App)      │
│  Result:            Global CDN Live URL (e.g. smartquiz.netlify) │
└──────────────────────────────────────────────────────────────────┘
```

#### Execution Steps Upon Approval:
1. Create `netlify.toml` and `public/_redirects` to configure Netlify deployment.
2. Update the in-app `ProjectHubModal.tsx` to include the **Netlify Deployment & Git Export** guide.
3. Create a clean project `README.md` with step-by-step Git, ZIP extraction, and Netlify instructions.
4. Run `npm run build` to verify production compilation succeeds without errors.
5. Generate `smartquiz-project.zip` in the root workspace excluding heavy `node_modules`.
